clear&&java -Xmx500m -Djava.library.path=lib -cp build:lib/mail.jar:lib/jmf.jar:lib/jnaerator-0.11-shaded.jar:lib/jna.jar:lib/platform.jar server.Server
