package interpreter;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class LexerParserTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testEvaluateExpression() {
		try {
			Function f=LexerParser.evaluateExpression("5");
			assertNotNull(f);
			
			OperationNodeDouble t=(OperationNodeDouble)f;
			assertNotNull(t);
			
			assertEquals(5, t.d, 0);
			
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getLocalizedMessage());
		}
		
	}

}
