package interpreter;

public class OperationNodePower extends AbstractOperationNode
{
	@Override
	Object execute(ExecutionEnvironment p) throws Exception
	{
		Object le=l.executeToVal(p), re=r.executeToVal(p);
		if (le instanceof Double && re instanceof Double) return Math.pow((Double)le,(Double)re);
		else throw new IllegalArgumentException();
	}

	@Override
	boolean bindLeft()
	{
		return true;
	}

	@Override
	boolean bindRight()
	{
		return true;
	}
}
