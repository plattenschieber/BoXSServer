package interpreter;

public class FunctionDebug extends Function {

	public FunctionDebug(int linenum, Function[] f) {
		super(linenum, f);
	}
	
	@Override
	Object execute(ExecutionEnvironment p) throws Exception {
		Object o=this.param[0].execute(p);
		System.out.println("debug: "+o);
		return o;
	}
}
