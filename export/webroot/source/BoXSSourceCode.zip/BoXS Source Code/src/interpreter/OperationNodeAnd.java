package interpreter;

public class OperationNodeAnd extends AbstractOperationNode
{
	@Override
	Object execute(ExecutionEnvironment p) throws Exception
	{
		Object le=l.executeToVal(p), re=r.executeToVal(p);
		if (le instanceof Double && re instanceof Double) return (((Double)le)!=0 && ((Double)re)!=0)?1d:0d;
		throw new IllegalArgumentException("Types do not match");
	}

	@Override
	boolean bindLeft()
	{
		return true;
	}

	@Override
	boolean bindRight()
	{
		return true;
	}
}
