package interpreter;


public abstract class OperationNodeOneArgumentFunction extends AbstractOperationNode
{
	
	public OperationNodeOneArgumentFunction(Function exp) {
		l=exp;
	}
	
	@Override
	boolean bindLeft()
	{
		return false;
	}

	@Override
	boolean bindRight()
	{
		return false;
	}
}
