package interpreter;

import client.Utils;

public class FunctionClientCommand extends Function{

	String type;
	FunctionClientCommand(int linenum, Function[] param, String _type) {
		super(linenum, param);
		type=_type;

	}

	@Override
	Object execute(ExecutionEnvironment p) throws Exception {

		
		
        if (p.sct!=null)
        {
            if (type.equals("inputNumber")
	        		|| type.equals("inputString")  || type.equals("inputNumberNC")
	        		|| type.equals("inputStringNC") || type.equals("choice") || type.equals("choiceRandomize") || type.equals("choiceRandomizeNC") 
	        		|| type.equals("choiceNC") || type.equals("checkbox") )
            {
            	String varname=ParsingUtils.resolveVarname((String)param[0].executeToVal(p), p);
            	//System.out.println(varname);
            	Object varval=p.varspaceGet(varname);
            	//System.out.println(varval);
            	if (varval!=null)
            		p.sct.updates.add(linenum+"@setdefault("+varname+",\""+Utils.getNiceString(varval).replaceAll("\n", "\\\\n")+"\")");
            }
        	
        	String output="";
        	for (Function f:param)
        	{
        		Object o=f.executeToVal(p);

        		String res;
            	if (o instanceof String)
            		res="\""+(String)o+"\"";
            	else 
            		res="\""+Utils.getNiceString(o)+"\"";
        		
            	if (!output.isEmpty())
            		output=output+","+res;
            	else
            		output=res;
        	}
            p.sct.updates.add(linenum+"@"+type+"("+output+")");
        }
		return 1d;
	}

}
