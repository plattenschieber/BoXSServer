package interpreter;


public abstract class OperationNodeNoArgumentFunction extends AbstractOperationNode
{
	
	@Override
	boolean bindLeft()
	{
		return false;
	}

	@Override
	boolean bindRight()
	{
		return false;
	}
}
