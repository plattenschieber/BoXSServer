package interpreter;

import java.util.Vector;

public class FunctionIf extends Function{
	Vector<Function> prog;
	
	FunctionIf(int linenum, Function[] param, Vector<Function> _prog) {
		super(linenum, param);
		prog=_prog;
	}

	@Override
	Object execute(ExecutionEnvironment p) throws Exception {
		boolean cond=(Double)param[0].executeToVal(p)!=0;
		if (cond)
		{
			for (Function f:prog)
				if (f!=null) 
				f.execute(p);
		}
		return null;
	}

}
