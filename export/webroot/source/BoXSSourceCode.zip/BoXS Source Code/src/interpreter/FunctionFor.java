package interpreter;

import java.util.Vector;

public class FunctionFor extends Function{
	Vector<Function> prog;
	
	FunctionFor(int linenum, Function[] param, Vector<Function> _prog) {
		super(linenum, param);
		prog=_prog;
	}

	@Override
	Object execute(ExecutionEnvironment p) throws Exception {
		int repcount=0;
		

		// init
		param[0].execute(p);		

				
		while ((Double)param[1].executeToVal(p)!=0 && !p.cancel)
		{
			for (Function f:prog)
				if (f!=null)
				f.execute(p);
		
			repcount++;
			if (repcount>500) throw new Exception("Possible infinite loop detected.");
		
			param[2].execute(p);
		}
		return null;
	}

}
