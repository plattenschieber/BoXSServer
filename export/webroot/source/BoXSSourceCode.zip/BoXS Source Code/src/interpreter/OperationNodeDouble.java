package interpreter;

public class OperationNodeDouble extends AbstractOperationNode
{
	Double d;
	public OperationNodeDouble(Double _d)
	{
		d=_d;
	}

	@Override
	Double execute(ExecutionEnvironment p)
	{
		return d;
	}

	@Override
	boolean bindLeft()
	{
		return false;
	}

	@Override
	boolean bindRight()
	{
		return false;
	}
	
	@Override
	public String toString() {
		return super.toString()+":"+d;
	}
}
