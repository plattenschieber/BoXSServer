package interpreter;

import java.util.Vector;

public class ParsingUtils {
	


	static String resolveVarname(String vname, ExecutionEnvironment p) throws Exception{
		try
		{
			if (vname.indexOf('[')!=-1)
			{ // Array
				String basevarname=vname.substring(0,vname.indexOf('['));
				String remainder=vname.substring(vname.indexOf('['));


				boolean waschanged=false;
				while (!remainder.isEmpty() && remainder.startsWith("["))
				{
					String eval=client.Utils.getMatchingLevelString(remainder,false,false);
					Object evaluateExpression = LexerParser.evaluateExpression(eval).execute(p);
					String o;
					if (evaluateExpression instanceof Double)
						o=""+((Double)evaluateExpression).intValue();
					else
						o=evaluateExpression.toString();

					basevarname+="["+o+"]";
					remainder=remainder.substring(eval.length()+2);
					waschanged=true;
				}
				if (waschanged) basevarname=basevarname+remainder;
				return basevarname;
			}
			return vname;
		}
		catch(Exception e)
		{
			throw new Exception("Unable to resolve variable name "+vname);
		}
	}




    public static String getVarnameFromMixedString(String orig) throws Exception {

    	String rem=orig;
    	int finalpos=0;
    	while (rem.length()>0)
    	{
    		if (isVariableCharacter(rem.charAt(0)))
    		{
    			rem=rem.substring(1);
    			finalpos++;
    		}
    		else if (rem.charAt(0)=='[')
    		{
    			String temp=client.Utils.getMatchingLevelString(rem,false,false);
				rem=rem.substring(temp.length()+2);
				finalpos+=temp.length()+2;
    		}
    		else if (finalpos!=0)
    			return orig.substring(0,finalpos);
    		else
    			return null;
    	}
		return orig.substring(0,finalpos);
	}


	public static boolean isVariableCharacter(char c)
    {
    	return (c>='a' && c<='z') || (c>='A' && c<='Z') || (c>='0' && c<='9') || c=='_' || c=='.';
    }


	public static boolean isNumberCharacter(char c)
    {
    	return (c>='0' && c<='9') || c=='.';
    }



    public static AbstractOperationNode findHighestPriority(Vector<AbstractOperationNode> list)
    {
    	// * /
    	for (AbstractOperationNode aon:list)
    	{
    		if (aon instanceof OperationNodeMultiply || aon instanceof OperationNodeDivide || aon instanceof OperationNodeRemainder)
    			if (!aon.allbound())
    				return aon;
    	}

    	// + -
    	for (AbstractOperationNode aon:list)
    	{
    		if (aon instanceof OperationNodeAdd || aon instanceof OperationNodeSubstract)
    			if (!aon.allbound())
    				return aon;
    	}

    	// == !=
    	for (AbstractOperationNode aon:list)
    	{
    		if (aon instanceof OperationNodeEquals || aon instanceof OperationNodeNEquals
    				|| aon instanceof OperationNodeLT|| aon instanceof OperationNodeLTE
    				|| aon instanceof OperationNodeGT|| aon instanceof OperationNodeGTE)
    			if (!aon.allbound())
    				return aon;
    	}

    	// && ||
    	for (AbstractOperationNode aon:list)
    	{
    		if (aon instanceof OperationNodeAnd || aon instanceof OperationNodeOr)
    			if (!aon.allbound())
    				return aon;
    	}

    	return list.get(0);
    }

}
