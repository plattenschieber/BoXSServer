package interpreter;

public class OperationNodeNEquals extends AbstractOperationNode
{
	@Override
	Object execute(ExecutionEnvironment p) throws Exception
	{
		Object le=l.executeToVal(p), re=r.executeToVal(p);
		if (le instanceof Double && re instanceof Double) return ((Double)le).equals((Double)re)?0d:1d;
		if (le instanceof String && re instanceof String) return le.toString().equals(re.toString())?0d:1d;
		try{
			if (le instanceof Double && re instanceof String) return ((Double)le).equals(Double.parseDouble((String)re))?0d:1d;
			if (re instanceof Double && le instanceof String) return ((Double)re).equals(Double.parseDouble((String)le))?0d:1d;
		}
		catch(Exception e)
		{
			return 1d;
		}

		throw new IllegalArgumentException("Types do not match: "+le.getClass()+" - "+ re.getClass());
}

	@Override
	boolean bindLeft()
	{
		return true;
	}

	@Override
	boolean bindRight()
	{
		return true;
	}
}
