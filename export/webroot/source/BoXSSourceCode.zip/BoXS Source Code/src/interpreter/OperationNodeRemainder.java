package interpreter;

public class OperationNodeRemainder extends AbstractOperationNode
{
	@Override
	Object execute(ExecutionEnvironment p) throws Exception
	{
		Object le=l.executeToVal(p), re=r.executeToVal(p);
		if (!(le instanceof Double)) throw new Exception(le.toString()+" not a Double");
		if (!(re instanceof Double)) throw new Exception(re.toString()+" not a Double");
		return (Double)le%(Double)re;
	}

	@Override
	boolean bindLeft()
	{
		return true;
	}

	@Override
	boolean bindRight()
	{
		return true;
	}
}
