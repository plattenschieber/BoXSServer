package interpreter;


public class OperationNodeRound extends AbstractOperationNode
{
	int nums;
	
	public OperationNodeRound(int _nums, Function exp) {
		nums=_nums;
		l=exp;
	}
	
	@Override
	Object execute(ExecutionEnvironment p) throws Exception
	{
		int f=(int)Math.pow(10, nums);
		Object le=l.executeToVal(p);
		return (double)Math.round( f*((Double)le).doubleValue())  /f ;
	}

	@Override
	boolean bindLeft()
	{
		return false;
	}

	@Override
	boolean bindRight()
	{
		return false;
	}
}
