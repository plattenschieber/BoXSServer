package interpreter;

import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import server.Group;
import server.ServerClientThread;
import server.Session;
import client.ErrorMessage;
import client.Utils;


public class ExecutionEnvironment extends Thread
{
    public final Map<String, Object> _varspace;

    public Vector<Function> prg;
    public ServerClientThread sct;
    public String role;
    public Group group;
    public Session session;
    int startLineNum;


    

    public ExecutionEnvironment(Vector<Function> _prg, int _startLineNum, ServerClientThread _sct, String _role,
    		Map<String, Object> __varspace, Group _group)
    {
    	prg=_prg;
    	sct=_sct;
    	role=_role;
    	group=_group;
    	startLineNum=_startLineNum;
    	_varspace=__varspace;
    	if (group!=null)
    	{
    		session=group.session;
    	}
    	if (sct!=null)
    	{
	    	sct.subinfo.experimentGroup=group.name;
	    	sct.subinfo.experimentRole=role;
	    	if (_varspace!=null && role!=null)
	    	{
	    		varspacePut("role", role);
	    		varspacePut("group", group.name);
	    		varspacePut("username", sct.subinfo.username);
	    		varspacePut("_finished", new Double(0));
	    		varspacePut("_linenum", new Double(startLineNum));
	    	}
    	}

    	// Nach 12 Stunden definitiv abbrechen
    	new Timer().schedule(new TimerTask()
    	{
			@Override
			public void run() {
				cancel=true;
			}
    		
    	},1000*60*60*12);
    }

    
    

	public void writeMatchingHistory(int linenum) {

    	// Matchhistory
    	String otherRoles=null;
    	for (ServerClientThread or:group.subjects.values())
    	{
    		if (!or.subinfo.username.equals(sct.subinfo.username))
    		{
    			if (otherRoles==null) otherRoles=or.subinfo.username;
    			else otherRoles+=","+or.subinfo.username;
    		}
    	}

    	if (otherRoles!=null)
    	{
	    	String matchHistory;
	    	Object _matchHistory=_varspace.get(sct.subinfo.username+"._matchinghistory");
	    	if (_matchHistory!=null)
	    		matchHistory=(String)_matchHistory+","+otherRoles;
	    	else
	    		matchHistory=otherRoles;
	    	_varspace.put(sct.subinfo.username+"._matchinghistory"+linenum,matchHistory);
    	}

	}


    public void varspacePut(Group group, String role, String varname, Object value)
    {
    	_varspace.put(getVarname(group, role, varname), value);

    }

    public void varspacePut(String role, String varname, Object value)
    {
    	_varspace.put(getVarname(role, varname), value);

    }

    public void varspacePut(String varname, Object value)
    {
  //  	System.out.println("put"+getVarname(varname));
    	_varspace.put(getVarname(varname), value);

    }

    public Object varspaceGet(Group group, String role, String varname)
    {
    	return _varspace.get(getVarname(group, role, varname));
    }

    public Object varspaceGet(String role, String varname)
    {
    	return _varspace.get(getVarname(role, varname));
    }

    public Object varspaceGet(String varname)
    {
   // 	System.out.println("get"+getVarname(varname));
    	return _varspace.get(getVarname(varname));
    }



	private String getVarname(Group _group, String _role, String varname)
	{
		return _group.subjects.get(_role).subinfo.username + "." + varname;
	}

	private String getVarname(String _role, String varname)
	{
		return group.subjects.get(_role).subinfo.username + "." + varname;
	}

	private String getVarname(String varname)
	{
		if(group!=null)
			return group.subjects.get(role).subinfo.username + "." + varname;
		else
			return randomSubjectname()+"."+varname;
	}


	
	public String randomSubjectname()
	{
		for (String k:_varspace.keySet())
			if (k.indexOf(".")!=-1)
				return k.substring(0,k.indexOf("."));
		return "";
	}
	
	
	



    //int skipuntilpara=-1, repeatline=-1, repeatpara=-1,ex=0;
	public boolean finished=false;

    public void run()
    {
    	
    		for (Function f:prg)
    		{
    			if (cancel) return;
            	
    	    	try {

	    			if (f!=null)
	    			{
	            		varspacePut( "_linenum", new Double(f.linenum));
	    				f.execute(this);
	    			}
    			} catch (Exception e) {
    				session.experimenter.send(new ErrorMessage(f.linenum, f.toString(), e.getMessage(), new java.util.Date()));
    				e.printStackTrace();
    			}
    		}
			varspacePut("_finished", new Double(1));
			finished=true;
			sct.updates.clear();
			sct.updates.add("finish");
			sct.executeUpdate();
    }
	
	


    void checkVarname(String vname) throws Exception {
    	if (vname.startsWith("_") || vname.equalsIgnoreCase("role")
    			 || vname.equalsIgnoreCase("group")  || vname.equalsIgnoreCase("username"))
    		throw new Exception("Cannot assign value to system variable "+vname);

	}







	String getOpponentRole() throws Exception{
		for (String r:group.subjects.keySet())
    	{	if (!r.equals(role))
    		{
    			return r;
    		}
    	}
    	throw new Exception("Opponent not found!");
	}



/*
	public boolean isWaiting()
	{
		if (varspace.containsKey(role+".continue")
			&& ((Double)varspace.get(role+".continue")).doubleValue()==1)
			return true;
		return false;
	}
*/

	boolean cancel=false;
	public void cancel()
	{
		cancel=true;
		interrupt();
	}

	Vector<AbstractOperationNode> assertions=new Vector<AbstractOperationNode>();
	public boolean inputHistory=true;

	



	public boolean submitValue(String _name, Object val, long time) throws Exception
	{
		//if (debug) System.out.println("submitted: "+_name+" -> "+val);
		// Resolve name
		String name=ParsingUtils.resolveVarname(_name.trim(),this);
		if (name.startsWith("\"")) name=name.substring(1,name.length()-1).trim();
		
		// increase if continue
		if (_name.startsWith("_continue"))
		{
			if (varspaceGet(name)!=null && varspaceGet(name) instanceof Double)
			{
				val=(Double)val+(Double)varspaceGet(name);
			}
		}
		
		// Historie schreiben
		Object history=varspaceGet("_inputhistory_"+name);
		String h="";
		if (history!=null)
			h=(String)history+",";
		h+=""+time+".\""+Utils.getNiceString(val)+"\"";
		if (inputHistory && !name.startsWith("_clientdisplaytime"))
		{
			if (h.length()>1024) h="[error: >1024, too big]";
			varspacePut("_inputhistory_"+name,h);
		}
	
		
		// Prüfen ob assertions vorher erfüllt waren
		/*boolean validbefore=true;
		for (AbstractOperationNode s:assertions)
		{
			try
			{
				Object res=s.executeToVal(this);
				if (!(res instanceof Double) || ((Double)res).doubleValue()!=1)
					validbefore=false;
			}
			catch(Exception e)
			{
				validbefore=false;
			}
		}*/

		// Prüfen ob assertions jetzt erfüllt sind
	//	Object prev=varspaceGet(name);

		varspacePut(name,val);
		return checkAssertions();

	}

	public boolean checkAssertions()
	{
		boolean valid=true;
		for (AbstractOperationNode s:assertions)
		{
			try
			{
				Object res=s.executeToVal(this);
				if (!(res instanceof Double) || ((Double)res).doubleValue()!=1)
					valid=false;
			}
			catch(Exception e)
			{
				valid=false;
			}
		}
		return valid;
	}
	

}
