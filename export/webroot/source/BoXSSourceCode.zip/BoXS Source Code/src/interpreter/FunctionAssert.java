package interpreter;


public class FunctionAssert extends Function {

	public FunctionAssert(int linenum, Function[] param) {
		super(linenum, param);
	}

	@Override
	public Object execute(ExecutionEnvironment p) throws Exception{
    	p.assertions.add((AbstractOperationNode)param[0]);

		return "ok";
	}

}
