package interpreter;

import java.util.Vector;

public abstract class AbstractOperationNode extends Function
{
	AbstractOperationNode() {
		super(0, null);
	}

	public Function l,r;

	abstract boolean bindLeft();
	abstract boolean bindRight();

	boolean allbound()
	{
		if (bindLeft()&&l==null) return false;
		if (bindRight()&&r==null) return false;
		return true;
	}

	abstract Object execute(ExecutionEnvironment p) throws Exception;

	
	
	@Override
	public String toString() {
		Vector<Function> f=new Vector<Function>();
		if (l!=null) f.add(l);
		if (r!=null) f.add(r);
		param=f.toArray(new Function[0]);
		return super.toString();
	}
}
