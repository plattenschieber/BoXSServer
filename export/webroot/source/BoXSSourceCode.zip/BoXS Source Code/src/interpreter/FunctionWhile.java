package interpreter;

import java.util.Vector;

public class FunctionWhile extends Function{

	Vector<Function> prog;
	
	FunctionWhile(int linenum, Function[] param, Vector<Function> _prog) {
		super(linenum, param);
		prog=_prog;
	}

	@Override
	Object execute(ExecutionEnvironment p) throws Exception {
		int repcount=0;
			
		while ( !p.cancel)
		{
			Object o=param[0].executeToVal(p);
			if ((Double)o==0) break;
			
			
			for (Function f:prog)
				if (f!=null)
					f.execute(p);
		
			repcount++;
			if (repcount>5000) throw new Exception("Possible infinite loop detected.");
		
		}
		return null;
	}

}
