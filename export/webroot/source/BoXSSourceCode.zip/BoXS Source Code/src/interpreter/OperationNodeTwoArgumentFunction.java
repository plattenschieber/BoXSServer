package interpreter;


public abstract class OperationNodeTwoArgumentFunction extends AbstractOperationNode
{
	
	public OperationNodeTwoArgumentFunction(Function exp1, Function exp2) {
		l=exp1; r=exp2;
	}
	
	@Override
	boolean bindLeft()
	{
		return false;
	}

	@Override
	boolean bindRight()
	{
		return false;
	}
}
