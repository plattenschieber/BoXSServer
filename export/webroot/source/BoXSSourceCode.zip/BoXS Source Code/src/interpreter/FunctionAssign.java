package interpreter;

import java.util.StringTokenizer;

import server.Group;

public class FunctionAssign extends Function {

	String _vname;
	
	public FunctionAssign(int linenum, Function[] param, String __vname) {
		super(linenum, param);
	  _vname=__vname;
	}

	@Override
	public Object execute(ExecutionEnvironment parser) throws Exception{
		String vname=ParsingUtils.resolveVarname(_vname, parser);
    	Object o=param[0].executeToVal(parser);


    	StringTokenizer st=new StringTokenizer(vname,".");
    	String[] temp=new String[st.countTokens()];
    	int i=0;

    	while(st.hasMoreElements())
    		temp[i++]=st.nextToken();


    	// Variablen
    	switch(temp.length)
    	{
    	case 1: //   test
    		parser.checkVarname(vname);
    		parser.varspacePut(parser.group, parser.role, vname, o);
    		break;
    	case 2: //   A.test
    		parser.checkVarname(temp[1]);
			if (temp[0].equalsIgnoreCase("opponent"))
				parser.varspacePut(parser.group, parser.getOpponentRole(), temp[1], o);
			else if (temp[0].equalsIgnoreCase("*"))
				for (String r:parser.group.subjects.keySet())
					parser.varspacePut(parser.group, r, temp[1], o);
			else
				parser.varspacePut(parser.group, temp[0], temp[1], o);
    		break;
    	case 3: //   1.A.test
    		parser.checkVarname(temp[2]);
    		if (temp[0].equalsIgnoreCase("*") && temp[1].equalsIgnoreCase("*"))
    		{	// *.*.test
				for (Group g:parser.group.session.groups.values())
					for (String r:g.subjects.keySet())
						parser.varspacePut(g, r, temp[2], o);
    		}
    		else if (temp[0].equalsIgnoreCase("*"))
    		{	// *.x.test
				for (Group g:parser.group.session.groups.values())
					parser.varspacePut(g, temp[1], temp[2], o);
    		}
    		else if (temp[1].equalsIgnoreCase("*"))
    		{	// *.x.test
				for (String r:parser.group.subjects.keySet())
					parser.varspacePut(parser.session.groups.get(temp[0]), r, temp[2], o);
    		}
    		else
    		{
    			parser.varspacePut(parser.session.groups.get(temp[0]), temp[1], temp[2], o);
    		}
    		break;
    	}

		return "ok";
	}

}
