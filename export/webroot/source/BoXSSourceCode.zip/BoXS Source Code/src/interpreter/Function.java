package interpreter;

public abstract class Function {
	int linenum;
	Function[] param;
	
	Function(int _linenum, Function[] _param){
		linenum=_linenum;
		param=_param;
	}

	abstract Object execute(ExecutionEnvironment p) throws Exception;
	
	public Object executeToVal(ExecutionEnvironment p) throws Exception
	{
		Object t=execute(p);
		if (t instanceof OperationNodeString) return ((OperationNodeString)t).s;
		if (t instanceof OperationNodeDouble) return ((OperationNodeDouble)t).d;
		return t;
	}
	
	public String executeToString(ExecutionEnvironment p) throws Exception
	{
		Object t=execute(p);
		if (t instanceof OperationNodeString) return ((OperationNodeString)t).s;
		if (t instanceof OperationNodeDouble) return ""+((OperationNodeDouble)t).d;
		return t.toString();
	}
	

	@Override
	public String toString() {
		String ret=this.getClass().getSimpleName();
		if (param!=null && param.length>0)
		{
			ret+=" (";
			for (Function f:param)
				ret+=f+",";
			ret=ret.substring(0, ret.length()-1)+")";
		}
		return ret;
	}
}
