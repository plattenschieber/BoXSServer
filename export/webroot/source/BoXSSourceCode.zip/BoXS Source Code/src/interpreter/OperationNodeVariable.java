package interpreter;


public class OperationNodeVariable extends AbstractOperationNode
{
	String _vname, rolename, groupname;

	
	public OperationNodeVariable(String __vname, String _rolename, String _groupname) {
		_vname=__vname; rolename=_rolename; groupname=_groupname; 
	}
	
	@Override
	Object execute(ExecutionEnvironment p) throws Exception {
		String vname=ParsingUtils.resolveVarname(_vname, p);
		Object ret;
		String _rolename=rolename;
	//	System.out.println(groupname+"-"+rolename+"-"+vname+"-");
		if (_rolename!=null && _rolename.equals("opponent"))
		{
			_rolename=p.getOpponentRole();
		}
		
		
		if (_rolename!=null && groupname!=null) 
			ret=p.varspaceGet(p.session.groups.get(groupname),_rolename,vname);
		else if (_rolename!=null)
			ret=p.varspaceGet(_rolename, vname);
		else 
			ret=p.varspaceGet(vname);
		if (ret==null) ret=0d;
		return ret;
	}
	
	@Override
	boolean bindLeft()
	{
		return false;
	}

	@Override
	boolean bindRight()
	{
		return false;
	}
	

	@Override
	public String toString() {
		return super.toString()+":"+groupname+"."+rolename+"."+_vname;
	}
}
