package interpreter;

import client.Utils;

public class OperationNodeAdd extends AbstractOperationNode
{
	@Override
	Object execute(ExecutionEnvironment p) throws Exception
	{
		Object le=l.executeToVal(p), re=r.executeToVal(p);
		
		if (le instanceof Double && re instanceof Double) return (Double)le+(Double)re;
		else return Utils.getNiceString(le)+Utils.getNiceString(re);
	}

	@Override
	boolean bindLeft()
	{
		return true;
	}

	@Override
	boolean bindRight()
	{
		return true;
	}
	

}
