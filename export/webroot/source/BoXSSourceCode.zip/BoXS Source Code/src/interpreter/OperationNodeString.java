package interpreter;

public class OperationNodeString extends AbstractOperationNode
{
	String s;
	public OperationNodeString(String _s)
	{
		s=_s;
	}

	@Override
	String execute(ExecutionEnvironment p)
	{
		return s.replaceAll("\\\"", "\"");
	}

	@Override
	boolean bindLeft()
	{
		return false;
	}

	@Override
	boolean bindRight()
	{
		return false;
	}
	

	@Override
	public String toString() {
		return super.toString()+":"+s;
	}
}
