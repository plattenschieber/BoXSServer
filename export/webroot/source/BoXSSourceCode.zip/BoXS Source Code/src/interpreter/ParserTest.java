package interpreter;

import java.util.Hashtable;
import java.util.Vector;

import server.Group;
import server.ServerClientThread;

public class ParserTest {
	public static void main(String[] args) {
		System.out.println("Full lexer/parser test");
		
		
		test("var=round(15/4+6)");
		test("debug(\"test\")");
		test("debug(5)");
		test("debug(-5)");
		test("a=5\ndebug(a>-5)");
		test("debug(5+5)");
		test("debug(2*3+4)");
		test("debug(2+3*4)");
		test("debug(time)");
		test("debug(timestring)");
		test("debug(username)");
		test("debug(role)");
		test("debug(group)");
		test("//test \n  debug(group)");
		test("debug(\"test \" + \"test2\" )");
		test("debug((2+3)*4)");
		test("debug(((2+3*4)))");
		test("a=5 \n debug(a)");
		test("a=2.5 \n b=13 \n c=b*a \n debug(2.5*b) \n debug(c)");
		test("debug(round(4/3))");
		test("debug(randomGauss())");
		
		test("i=1 \n i=1+i \n debug(i) ");
		test("i=1 \n i=i+1 \n debug(i) ");
		test("i=1 \n while(i<=5) \n { \n debug(i) \n i=i+1 \n 	}");
		test("for (i=1; i<=5; i=i+1) \n { \n debug(i)  \n 	}");
					
		test("debug(round(4/3)+\"a\")");
		test("debug(randomGauss()+\"=hallo\")");
		test("a[5]=3\ndebug(a[5])");
		test("a[2+3]=3\ndebug(a[10/2])");
		test("i=3\na[i]=3\ndebug(a[3])");
		test("i=3\na[i]=3\ndebug(a[i])");
		test("a[5][2]=3\ndebug(a[20/4][1+1])");
		test("a[3]=1\nb[a[3]]=3\ndebug(b[a[3]])");
		test("a[5]=3==4\ndebug(a[5])");
		test("debug(a)");
		test("debug(a[5])");
		test("a[5==3]=3\ndebug(a[1])");
		test("a[5==5]=3\ndebug(a[1])");
		test("s=\"<table>\" \n s=s+\"<td align=center width=40>\"+(i*j)+\"</td>\"  \n debug(s)");
		test("  s =  \"<table>\" \n   s = s + \"<td align=center width=40>\"+(i*j)+\"</td>\"  \n debug(s)");
		System.exit(0);
	}

	private static void test(String string) {
		System.out.println("\nProgram: ");
		
		int i=1;
		for (String line:string.split("\n"))
		{
			System.out.println(" "+(i++)+": "+line.trim());
		}
		Hashtable<String, Object> varspace=new Hashtable<String, Object>();
		Group g=new Group(null, "1", 0);
		
		try {
			ServerClientThread sct=new ServerClientThread(null, null, null, null, null);
			sct.subinfo.username="testuser";
			
			g.assignSubjectToExperiment(null, sct, "A", null, 0, varspace);
			System.out.print("creating...");

			System.out.print("  lexing/parsing...");
			Vector<Function> prog=LexerParser.parseProgram(string, 0);
			
			
			System.out.println("  done! Executing...");

			ExecutionEnvironment p=new ExecutionEnvironment(prog, 0, sct, "A", varspace, g);
			i=1;
			for (Function f:prog)
			{
				System.out.println(" "+(i++)+": "+f);
				if (f!=null) f.execute(p);
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
}
