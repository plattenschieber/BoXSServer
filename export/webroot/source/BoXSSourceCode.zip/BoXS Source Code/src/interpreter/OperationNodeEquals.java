package interpreter;

public class OperationNodeEquals extends AbstractOperationNode
{
	@Override
	Object execute(ExecutionEnvironment p) throws Exception
	{
		Object le=l.executeToVal(p), re=r.executeToVal(p);
//		System.out.println("le=[" + le + "]"); // FIXME Debug log le
	//	System.out.println("re=[" + re + "]"); // FIXME Debug log re
		if (le instanceof Double && re instanceof Double) return ((Double)le).equals((Double)re)?1d:0d;
		if (le instanceof String && re instanceof String) return le.toString().equals(re.toString())?1d:0d;
		
		try
		{
		if (le instanceof Double && re instanceof String) return ((Double)le).equals(Double.parseDouble((String)re))?1d:0d;
		if (re instanceof Double && le instanceof String) return ((Double)re).equals(Double.parseDouble((String)le))?1d:0d;
		}
		catch(Exception e)
		{
			return 0d;
		}
		throw new IllegalArgumentException("Types do not match: "+le.getClass()+" - "+ re.getClass());
	}

	@Override
	boolean bindLeft()
	{
		return true;
	}

	@Override
	boolean bindRight()
	{
		return true;
	}
}
