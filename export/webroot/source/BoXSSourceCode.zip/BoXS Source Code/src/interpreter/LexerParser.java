package interpreter;

import static interpreter.ParsingUtils.findHighestPriority;
import static interpreter.ParsingUtils.getVarnameFromMixedString;
import static interpreter.ParsingUtils.isNumberCharacter;

import java.util.Collections;
import java.util.Date;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.Vector;

import client.ErrorMessage;
import client.ServerSideValidInfo;

public class LexerParser {


    
	public static Vector<Function> parseProgram(String program, int executestartlinenum) throws ErrorMessage
	{
		Vector<Function> ret=new Vector<Function>();
    	String[] progline=program.split("\n");
        mainparseloop: for (int line=0; line<progline.length; line++)
        {
        	String s=progline[line];

        	try
        	{

//            		varspacePut("_infloop", new Double(1));
    			// Test for if/while
    			if (s.indexOf("(")>=0)
    			{
	                String command, param;
	                command=s.substring(0,s.indexOf("(")).trim();
	                param=s.substring(s.indexOf("(")+1, s.lastIndexOf(")")).trim();

	    	        if (command.equals("if") || command.equals("while") || command.equals("for"))
	    	        {

	    	        	String remprg=new String();
	    	        	for (int l=line+1; l<progline.length; l++)
	    	        	{
	    	        		remprg+=progline[l]+"\n";
	    	        	}

	    	        	String block=client.Utils.getMatchingLevelString(remprg.trim(),false, false);
	    	        	int blocklength=block.split("\n").length;
	    	        	if (block.endsWith("\n")) blocklength++;

	    	        	if (command.equals("if"))
	    	        	{ // if
	    	        		Function[] para={evaluateExpression(param)};
	    	        		Vector<Function> subprog=parseProgram(block,executestartlinenum+line+1);
	    	        		ret.add(new FunctionIf(executestartlinenum+line, para, subprog));
	    	        	}
	    	        	else if (command.equals("while"))
	    	        	{ // while
	    	        		Function[] para={evaluateExpression(param)};
	    	        		Vector<Function> subprog=parseProgram(block,executestartlinenum+line+1);
	    	        		ret.add(new FunctionWhile(executestartlinenum+line, para, subprog));
	    	        	}
	    	        	else if (command.equals("for"))
	    	        	{ // for
	    	        		String[] param2=param.split(";");
	    	        		if (param2.length!=3) throw new Exception("Invalid for statement: "+param);
	    	        		Function[] para={parseLine(param2[0], 0),
	    	        				evaluateExpression(param2[1]),
	    	        				parseLine(param2[2], 0)};
	    	        		
	    	        		Vector<Function> subprog=parseProgram(block,executestartlinenum+line+1);
	    	        		ret.add(new FunctionFor(executestartlinenum+line, para, subprog));
	    	        	}
	    	        	line+=blocklength;
	    	        	continue mainparseloop;
	    	        }


    			}

    			ret.add(parseLine(s,executestartlinenum+line));
        	}
        	catch(ErrorMessage e)
        	{
        		System.err.println("Relaying Error Message");
        		e.printStackTrace();
        		throw e;
        	}
        	catch(Exception e)
        	{
        		e.printStackTrace();
        		throw new ErrorMessage(executestartlinenum+line, s, e.getMessage(),new java.util.Date());
        	}

        }

        return ret;

//        sct.update();
        
	}

	static final boolean debug=false;

	
	
/*
    public String parseLine(String _line, int linenum) throws ParsingException
    {
    	Function f=internalParseLine(_line, linenum);
    	if (f==null) return "ok";
    	return (String)f.execute();
    }
	*/
    public static Function parseLine(String _line, int linenum) throws Exception
    {
        String line=_line.trim();
        if (debug) System.out.println("Parsing: "+_line);
        
        if (line.isEmpty() || line.startsWith("//")) return null;

        boolean assignment=false;

        int para=0;

        for (int i=0; i<line.length(); i++)
        {
        	if (line.charAt(i)=='(') para++;
        	if (line.charAt(i)==')') para--;
        	if (para==0 && line.charAt(i)=='=')
        		assignment=true;
        }

        if (assignment)
        {
        	String vname=client.Utils.getMatchingLevelString(_line, false, true);
        	String exp=_line.substring(vname.length()+1);
        	vname=vname.trim();
        	exp=exp.trim();
        	Function[] f={evaluateExpression(exp)};
        	return new FunctionAssign(linenum,f, vname);
        }
        else
        {
        	if (!line.trim().isEmpty())
        	{
            String command, param;
            command=line.substring(0,line.indexOf("(")).trim();
            param=line.substring(line.indexOf("(")+1, line.lastIndexOf(")")).trim();


            Vector<String> paramparts=client.Utils.splitByComma(param);



            int noevalcount=0;
	        if (command.equals("assert"))
	        {
	        	noevalcount=1;
	        }
	        if (command.startsWith("inputNumber"))
	        {
	        	noevalcount=1;
	        }
	        if (command.startsWith("inputString"))
	        {
	        	noevalcount=1;
	        }
	        if (command.startsWith("choice") || command.startsWith("choiceRandomize"))
	        {
	        	noevalcount=1;
	        }
	        if (command.equals("button"))
	        {
	        	noevalcount=1;
	        }
	        if (command.equals("checkbox"))
	        {
	        	noevalcount=1;
	        }





/*

	        int num=0;
            String output="";
            for (String s:paramparts)
            {
            	String res;
            	if (num<noevalcount)
            		res=s;
            	else
            		res=Utils.getNiceString(evaluateExpression(s));

            	if (res instanceof String)
            		res="\""+res+"\"";
            	num++;

            	if (!output.isEmpty())
            		output=output+","+res;
            	else
            		output=res;
            }
*/
	        
            if (command.equals("debug"))
            {
             	Function[] f={evaluateExpression(param)};
         	      	return new FunctionDebug(linenum,f);
            	
            }
            
	        
 
	        if (command.equals("display") || command.equals("video") || command.equals("inputNumber")
	        		|| command.equals("inputString")  || command.equals("inputNumberNC")
	        		|| command.equals("inputStringNC") || command.equals("choice") || command.equals("choiceRandomize") || command.equals("choiceRandomizeNC") 
	        		|| command.equals("choiceNC") || command.equals("checkbox") || command.equals("style") || command.equals("button")   
	        		|| command.equals("manualLayout") || command.equals("automaticLayout") 
	        		|| command.equals("clear"))
	        {
	        	Vector<Function> f=new Vector<Function>();
		        int num=0;
	            for (String s:paramparts)
	            {
	            	if (num<noevalcount)
	            		f.add(new OperationNodeString(s));
	            	else
	            		f.add(evaluateExpression(s));
	            	num++;
	            }
	            
	     
	            
	            if (command.equals("choiceRandomize") || command.equals("choiceRandomizeNC") )
	            {
				        Vector<Function> g=new Vector<Function>();
			            	g.add(f.get(0));
					f.remove(0);
					while(f.size()>0)
					{
						int i=(int)(Math.random()*f.size());
							    	g.add(f.get(i));
								f.remove(i);
					}
					command=command.equals("choiceRandomize")?"choice":"choiceNC";
					f=g;
	            }
	            
	            return new FunctionClientCommand(linenum, f.toArray(new Function[0]), command);
	        }
	        

	        if (command.equals("assert"))
	        {
	        	Function[] f={evaluateExpression(param)};
	            return new FunctionAssert(linenum, f);
	        }
	      

            
	        
	        if (command.equals("disableInputHistory"))
	        	return new Function(linenum, null) {
					@Override
					public Object execute(ExecutionEnvironment p) throws Exception {
						p.inputHistory=false;
			        	return 1d;
					}
				};
	        if (command.equals("enableInputHistory"))
	        	return new Function(linenum, null) {
					@Override
					public Object execute(ExecutionEnvironment p) throws Exception {
			        	p.inputHistory=true;
			        	return 1d;
					}
				};

				
	        if (command.equals("wait"))
	        {
	        	Function[] f={
	        			(paramparts.size()>=1)?evaluateExpression(paramparts.get(0)):new OperationNodeString("Continue"),  
	        			(paramparts.size()>=2)?evaluateExpression(paramparts.get(1)):new OperationNodeString("Please wait for the experiment to continue"),
	        				(paramparts.size()>=3)?evaluateExpression(paramparts.get(2)):new OperationNodeDouble(0d),
	    	        		(paramparts.size()>=4)?evaluateExpression(paramparts.get(3)):new OperationNodeDouble(0d),
	    	    	        (paramparts.size()>=5)?evaluateExpression(paramparts.get(4)):new OperationNodeDouble(0d),
	    	    	    	(paramparts.size()>=6)?evaluateExpression(paramparts.get(5)):new OperationNodeDouble(0d),
	        		};

	        	return new Function(linenum,f) {
					
					@Override
					public Object execute(ExecutionEnvironment p) throws Exception {
			            if (p.sct!=null)
			            {
			            	p.varspacePut("_continue"+(p.startLineNum+linenum), new Double(0));
		            		String line=linenum+"@wait("+(p.startLineNum+linenum)+","+param[0].execute(p)+","+param[1].execute(p)
            				+","+param[2].executeToVal(p)+","+param[3].executeToVal(p)+","+param[4].executeToVal(p)+","+param[5].executeToVal(p)+")";
		            		p.sct.updates.add(line);

			            	boolean temp=p.checkAssertions();
			            	p.sct.send(new ServerSideValidInfo(temp));
  		
			            	p.sct.update();


			                while(((Double)p.varspaceGet("_continue"+(p.startLineNum+linenum))).doubleValue()==0  && !p.cancel)
			                {
			               		try
								{
									Thread.sleep(200);
								}
								catch (InterruptedException e)
								{
						            return "ok";
								}
			                }
			            }
			            p.assertions.clear();
			            return "ok";
					}
				};
	        }


			if (command.equals("waitTime"))
	        {
	        	Function[] f={evaluateExpression(param)};
	        	return new Function(linenum,f) {
					
					@Override
					public Object execute(ExecutionEnvironment p) throws Exception {
				
		            	boolean temp=p.checkAssertions();
		            	p.sct.send(new ServerSideValidInfo(temp));

		   
				                p.sct.update();
					        	Double time=(Double)param[0].execute(p);
				           		try
								{
				           			Thread.sleep(time.longValue());
								}
								catch (InterruptedException e)
								{
						            return "ok";
								}
					            p.assertions.clear(); // ?
					            return "ok";
					}
				};
	        }
	        if (command.equals("waitForExperimenter"))
	        {
	        	
	        	Function[] f={evaluateExpression(param)};
	        	return new Function(linenum,f) {
					
					@Override
					public Object execute(ExecutionEnvironment p) throws Exception {
						
			            if (p.sct!=null)
			            {
			            	boolean temp=p.checkAssertions();
			            	p.sct.send(new ServerSideValidInfo(temp));

			                p.sct.update();
			                while(!p.sct.experiment.experimenter.ready && !p.cancel)
			                {
			                	try
								{
			                		Thread.sleep(200);
								}
								catch (InterruptedException e)
								{
						            return "ok";
								}
			                }
			            }
			            p.assertions.clear(); // ?
			            return "ok";
					}
				};
	        }
	        if (command.equals("waitForPlayers"))
	        {
	        	Function[] f={
	        			(paramparts.size()>=1)?evaluateExpression(paramparts.get(0)):new OperationNodeString("Continue"),  
	        			(paramparts.size()>=2)?evaluateExpression(paramparts.get(1)):new OperationNodeString("Please wait for the experiment to continue"),
	        				(paramparts.size()>=3)?evaluateExpression(paramparts.get(2)):new OperationNodeDouble(0d),
	    	        		(paramparts.size()>=4)?evaluateExpression(paramparts.get(3)):new OperationNodeDouble(0d),
	    	    	        (paramparts.size()>=5)?evaluateExpression(paramparts.get(4)):new OperationNodeDouble(0d),
	    	    	    	(paramparts.size()>=6)?evaluateExpression(paramparts.get(5)):new OperationNodeDouble(0d),
	        		};

	        	return new Function(linenum,f) {
					
					@Override
					public Object execute(ExecutionEnvironment p) throws Exception {
						
		            	
						
		            if (p.sct!=null)
		            {
		            	// Zielnummer ermitteln
						int waituntilcount=1;
						Object o=p.varspaceGet(p.group, p.role, "_continue"+(p.startLineNum+linenum));
						if (o!=null && o instanceof Double) waituntilcount+=(Double)o;

	            		p.sct.updates.add(linenum+"@wait("+(p.startLineNum+linenum)+","+param[0].execute(p)+","+param[1].execute(p)
	            				+","+param[2].executeToVal(p)+","+param[3].executeToVal(p)+","+param[4].executeToVal(p)+","+param[5].executeToVal(p)+")");
             
		            	boolean temp=p.checkAssertions();
		            	p.sct.send(new ServerSideValidInfo(temp));
	            		p.sct.update();
	
		                boolean playernotfinished=true;
		                while(playernotfinished && !p.cancel)
		                {
		                	try
		                	{
		                    	playernotfinished=false;
		                    	Thread.sleep(200);
		                    	for (String player:p.group.subjects.keySet())
		                    	{
		                    		if (p.varspaceGet(player, "_continue"+(p.startLineNum+linenum))==null)
		                    			playernotfinished=true;
		                    		else if (((Double)p.varspaceGet(player, "_continue"+(p.startLineNum+linenum))).doubleValue()<waituntilcount)
		                    			playernotfinished=true;
		                    	}
		                	}
							catch (InterruptedException e)
							{
					            return "ok";
							}
		                	catch(Exception e)
		                	{
		                		e.printStackTrace();
		                	}
		                }
		                
		              
		            }
		            p.assertions.clear(); // ?
		            return "ok";
				}
			};
	        }
        	}

        }


        throw new Exception("Command not recognized.");
    }




	@SuppressWarnings("deprecation")
	public static Function evaluateExpression(String _exp) throws Exception
    {
//		System.out.println("EXP"+_exp);
        String rem=_exp.trim();
        if (rem.isEmpty())return null;// throw new ParsingException("Empty expression: "+rem);


        // Aufst�ckeln & Umwandeln
        Vector<AbstractOperationNode> ons=new Vector<AbstractOperationNode>();

        long prevlength=rem.length();
        while(rem.length()>0)
        {
  //  		System.out.println("REM"+rem);
            rem=rem.trim();

        	if (rem.startsWith("\""))
            {
            	int end=1;
            	while (true)
            	{
            		end=rem.indexOf("\"",end);
            		if (end==-1) throw new Exception("Syntax error: '"+rem+"' in '"+_exp+"'");
            		if (rem.charAt(end-1)=='\\')
            		{
            			rem=rem.substring(0,end-1)+rem.substring(end);
            		}
            		else
            		{
            			break;
            		}
            		end++;
            	}

                ons.add(new OperationNodeString(rem.substring(1,end)));
                rem=rem.substring(end+1);
            	continue;
            }

            if (rem.startsWith("("))
            {
            	int blvl=0;
            	for (int i=0; i<rem.length(); i++)
            	{
            		if (rem.charAt(i)=='(') blvl++;
            		if (rem.charAt(i)==')') blvl--;
            		if (blvl==0)
            		{
                        ons.add((AbstractOperationNode)evaluateExpression(rem.substring(1,i)));
            			rem=rem.substring(i+1);
            			break;
            		}
            	}
            	continue;
            }

            if (rem.length()>0 && (isNumberCharacter(rem.charAt(0))
            		|| (rem.charAt(0)=='-'&&(ons.isEmpty() || ons.lastElement().bindRight()))))
            {
            	String num="";

            	while (rem.length()>0 && (isNumberCharacter(rem.charAt(0))
            		|| (rem.charAt(0)=='-'&&num.isEmpty()&&(ons.isEmpty() || ons.lastElement().bindRight()))
            			))
            	{
            		num+=rem.charAt(0);
            		rem=rem.substring(1);
            	}

                ons.add(new OperationNodeDouble(Double.parseDouble(num)));
            	continue;

            }


            if (rem.charAt(0)=='^')
            {
            	ons.add(new OperationNodePower());
                rem=rem.substring(1);
            	continue;
            }
            if (rem.startsWith("*"))
            {
            	ons.add(new OperationNodeMultiply());
                rem=rem.substring(1);
            	continue;
            }
            if (rem.startsWith("/"))
            {
            	ons.add(new OperationNodeDivide());
                rem=rem.substring(1);
            	continue;
            }
            if (rem.startsWith("%"))
            {
            	ons.add(new OperationNodeRemainder());
                rem=rem.substring(1);
            	continue;
            }
            if (rem.startsWith("+"))
            {
            	ons.add(new OperationNodeAdd());
                rem=rem.substring(1);
            	continue;
            }
            if (rem.startsWith("-"))
            {
            	ons.add(new OperationNodeSubstract());
                rem=rem.substring(1);
            	continue;
            }
            if (rem.startsWith("=="))
            {
            	ons.add(new OperationNodeEquals());
                rem=rem.substring(2);
            	continue;
            }
            if (rem.startsWith("!="))
            {
            	ons.add(new OperationNodeNEquals());
                rem=rem.substring(2);
            	continue;
            }
            if (rem.startsWith("<="))
            {
            	ons.add(new OperationNodeLTE());
                rem=rem.substring(2);
            	continue;
            }
            if (rem.startsWith(">="))
            {
            	ons.add(new OperationNodeGTE());
                rem=rem.substring(2);
            	continue;
            }
            if (rem.startsWith("<"))
            {
            	ons.add(new OperationNodeLT());
                rem=rem.substring(1);
            	continue;
            }
            if (rem.startsWith(">"))
            {
            	ons.add(new OperationNodeGT());
                rem=rem.substring(1);
            	continue;
            }
            if (rem.startsWith("&&"))
            {
            	ons.add(new OperationNodeAnd());
                rem=rem.substring(2);
            	continue;
            }
            if (rem.startsWith("||"))
            {
            	ons.add(new OperationNodeOr());
                rem=rem.substring(2);
            	continue;
            }


            // Commands
            if (rem.startsWith("round1"))
            {
            	String substr=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);
            	ons.add(new OperationNodeRound(1, evaluateExpression(substr))) ;
                rem=rem.substring(rem.indexOf('(')+substr.length()+2);
            	continue;
            }
            if (rem.startsWith("round2"))
            {
            	String substr=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);
            	ons.add(new OperationNodeRound(2, evaluateExpression(substr))) ;
                rem=rem.substring(rem.indexOf('(')+substr.length()+2);
            	continue;
            }
            if (rem.startsWith("round"))
            {
            	String substr=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);
            	ons.add(new OperationNodeRound(0, evaluateExpression(substr))) ;
                rem=rem.substring(rem.indexOf('(')+substr.length()+2);
            	continue;
            }
            if (rem.startsWith("exp"))
            {
            	String substr=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);
            	ons.add(new OperationNodeOneArgumentFunction(evaluateExpression(substr)) {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
						return Math.exp((Double)l.execute(p));
					}
				});
                rem=rem.substring(rem.indexOf('(')+substr.length()+2);
            	continue;
            }
            if (rem.startsWith("log"))
            {
            	String substr=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);
            	ons.add(new OperationNodeOneArgumentFunction(evaluateExpression(substr)) {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
						return Math.log((Double)l.execute(p));
					}
				});
                rem=rem.substring(rem.indexOf('(')+substr.length()+2);
            	continue;
            }
            if (rem.startsWith("abs"))
            {
            	String substr=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);
            	ons.add(new OperationNodeOneArgumentFunction(evaluateExpression(substr)) {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
						return Math.abs((Double)l.execute(p));
					}
				});
                rem=rem.substring(rem.indexOf('(')+substr.length()+2);
            	continue;
            }
            if (rem.startsWith("sin"))
            {
            	String substr=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);
            	ons.add(new OperationNodeOneArgumentFunction(evaluateExpression(substr)) {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
						return Math.sin((Double)l.execute(p));
					}
				});
                rem=rem.substring(rem.indexOf('(')+substr.length()+2);
            	continue;
            }
            if (rem.startsWith("cos"))
            {
            	String substr=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);
            	ons.add(new OperationNodeOneArgumentFunction(evaluateExpression(substr)) {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
						return Math.cos((Double)l.execute(p));
					}
				});
                rem=rem.substring(rem.indexOf('(')+substr.length()+2);
            	continue;
            }
            if (rem.startsWith("sqrt"))
            {
            	String substr=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);
            	ons.add(new OperationNodeOneArgumentFunction(evaluateExpression(substr)) {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
						return Math.sqrt((Double)l.execute(p));
					}
				});
                rem=rem.substring(rem.indexOf('(')+substr.length()+2);
            	continue;
            }
            if (rem.startsWith("tan"))
            {
            	String substr=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);
            	ons.add(new OperationNodeOneArgumentFunction(evaluateExpression(substr)) {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
						return Math.tan((Double)l.execute(p));
					}
				});
                rem=rem.substring(rem.indexOf('(')+substr.length()+2);
            	continue;
            }

            
            if (rem.startsWith("sum"))
            {
            	final String varname=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);

            	ons.add(new OperationNodeNoArgumentFunction() {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
						// TODO Auto-generated method stub
		            	double sum=0;

		                for (String player:p.group.subjects.keySet())
		                {
		                	if (p.varspaceGet(player, varname)==null) throw new Exception("Var for sum not found: "+player+"/"+varname);
		                	sum+=(Double)(p.varspaceGet(player, varname));
		                }
		                return sum;
					}
				}) ;
                rem=rem.substring(rem.indexOf('(')+varname.length()+2);
            	continue;
            }
            if (rem.startsWith("mean"))
            {
            	final String varname=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);
            	ons.add(new OperationNodeNoArgumentFunction() {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
						// TODO Auto-generated method stub
		            	double sum=0, count=0;

		                for (String player:p.group.subjects.keySet())
		                {
		                	String name=p.group+"."+player+"."+varname;
		                	if (p.varspaceGet(player, varname)==null) throw new Exception("Var for mean not found: "+name);
		                	sum+=(Double)p.varspaceGet(player, varname);
		                	count++;
		                }
		            	if (count==0) throw new Exception("No vars found ");
		                return sum/count;
					}
				}) ;
            	
                rem=rem.substring(rem.indexOf('(')+varname.length()+2);
            	continue;
            }
            if (rem.startsWith("min"))
            {
            	final String varname=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);

            	ons.add(new OperationNodeNoArgumentFunction() {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
		            	double min=Double.MAX_VALUE;
						// TODO Auto-generated method stub
		                for (String player:p.group.subjects.keySet())
		                {
		                	String name=p.group+"."+player+"."+varname;
		                	if (p.varspaceGet(player, varname)==null) throw new Exception("Var for mean not found: "+name);
		                	if ((Double)p.varspaceGet(player, varname)<min) min=(Double)p.varspaceGet(player, varname);
		                }
		                return min;
		                }
				}) ;

                rem=rem.substring(rem.indexOf('(')+varname.length()+2);
            	continue;
            }
            if (rem.startsWith("max"))
            {
            	final String varname=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);

            	ons.add(new OperationNodeNoArgumentFunction() {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
		            	double max=Double.MIN_VALUE;
					// TODO Auto-generated method stub
		                for (String player:p.group.subjects.keySet())
		                {
		                	String name=p.group+"."+player+"."+varname;
		                	if (p.varspaceGet(player, varname)==null) throw new Exception("Var for mean not found: "+name);
		                	if ((Double)p.varspaceGet(player, varname)>max) max=(Double)p.varspaceGet(player, varname);
		                }
		                return max;
		                }
				}) ;

                rem=rem.substring(rem.indexOf('(')+varname.length()+2);
            	continue;
            }
            if (rem.startsWith("median"))
            {
            	final String varname=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);

            	ons.add(new OperationNodeNoArgumentFunction() {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
		                Vector<Double> nums=new Vector<Double>();
		                for (String player:p.group.subjects.keySet())
		                {
		                	String name=p.group+"."+player+"."+varname;
		                	if (p.varspaceGet(player, varname)==null) throw new Exception("Var for mean not found: "+name);
		                	nums.add(new Double((Double)p.varspaceGet(player, varname)));
		                }
		                Collections.sort(nums);
		                return nums.get((int)(p.group.subjects.size()/2));
		                }
				}) ;


                rem=rem.substring(rem.indexOf('(')+varname.length()+2);
            	continue;
            }

            
            // string functions
            if (rem.startsWith("strlen"))
            {
            	String substr=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);
            	ons.add(new OperationNodeOneArgumentFunction(evaluateExpression(substr)) {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
						return new Double(((String)l.execute(p)).length());
					}
				});
                rem=rem.substring(rem.indexOf('(')+substr.length()+2);
            	continue;
            }
            if (rem.startsWith("strucase"))
            {
            	String substr=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);
            	ons.add(new OperationNodeOneArgumentFunction(evaluateExpression(substr)) {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
						return ((String)l.execute(p)).toUpperCase();
					}
				});
                rem=rem.substring(rem.indexOf('(')+substr.length()+2);
            	continue;
            }
            if (rem.startsWith("strlcase"))
            {
            	String substr=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);
            	ons.add(new OperationNodeOneArgumentFunction(evaluateExpression(substr)) {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
						return ((String)l.execute(p)).toLowerCase();
					}
				});
                rem=rem.substring(rem.indexOf('(')+substr.length()+2);
            	continue;
            }

            
            

            if (rem.startsWith("randomUniformInteger"))
            {
            	String substr=client.Utils.getMatchingLevelString(rem.substring(rem.indexOf('(')), false, false);
            	String[] parameters=substr.split(",");

            	ons.add(new OperationNodeTwoArgumentFunction(evaluateExpression(parameters[0]), 
            			evaluateExpression(parameters[1])) {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
		            	int from=((Double)l.execute(p)).intValue();
		            	int   to=((Double)r.execute(p)).intValue();
						return Double.valueOf(from+new Random().nextInt(to-from+1));
					}
				});
                rem=rem.substring(rem.indexOf('(')+substr.length()+2);
            	continue;
            }
            if (rem.startsWith("randomGauss"))
            {
            	ons.add(new OperationNodeOneArgumentFunction(null) {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
						return new Random().nextDouble();
					}
				});
                rem=rem.substring(rem.indexOf(')')+1);
            	continue;
            }
            if (rem.startsWith("randomUniform"))
            {
            	ons.add(new OperationNodeOneArgumentFunction(null) {
					
					@Override
					Object execute(ExecutionEnvironment p) throws Exception {
						return new Random().nextDouble();
					}
				});
                rem=rem.substring(rem.indexOf(')')+1);
            	continue;
            }




            if (rem.length()>0 && (rem.charAt(0)>='a'&&rem.charAt(0)<='z'
            	|| rem.charAt(0)>='A'&&rem.charAt(0)<='Z'|| rem.charAt(0)>='0'&&rem.charAt(0)<='9' || rem.charAt(0)=='_'))
            {	// Variable

            	String temp1=getVarnameFromMixedString(rem);
            	if (temp1==null) throw new Exception("Invalid varname "+rem);
            	rem=rem.substring(temp1.length());
            	String vname=temp1;

            	StringTokenizer st=new StringTokenizer(vname,".");
            	String[] temp=new String[st.countTokens()];
            	int i=0;

            	while(st.hasMoreElements())
            		temp[i++]=st.nextToken();





            	// Variablen suchen
            	switch(temp.length)
            	{
            		case 1: // vname
            			
            		   	if (vname.matches("time"))
                    	{
                    		ons.add(new OperationNodeNoArgumentFunction() {
        						
        						@Override
        						Object execute(ExecutionEnvironment p) throws Exception {
        							return (double)new Date().getTime();
        						}
        					});
                    	}
            		   	else if (vname.matches("timestring"))
                    	{
                    		ons.add(new OperationNodeNoArgumentFunction() {
        						
        						@Override
        						Object execute(ExecutionEnvironment p) throws Exception {
        							return new Date().toLocaleString();
        						}
        					});
                    	}
                    	else if (vname.matches("PI"))
                    	{
                    		ons.add(new OperationNodeDouble(Math.PI));
                    	}
                    	else
                    	{
                    		ons.add(new OperationNodeVariable(temp[0],null,null));
                    	}
            			
            			break;
            		case 2: // role.vname
                  		ons.add(new OperationNodeVariable( temp[1],temp[0],null));
            			break;
            		case 3: // group.role.vname
                		ons.add(new OperationNodeVariable(temp[2],temp[1],temp[0]));
            			break;
            	}

    			continue;
            }

            if (prevlength==rem.length())
        		throw new Exception("Syntax error: "+rem);
            prevlength=rem.length();
        }

        
        
        
        
        
        
//System.out.println("");

//int prevsize=ons.size();

        // Verketten
        while(ons.size()>1)
        {
//        	System.out.println("");
  //      	for (AbstractOperationNode aon:ons)
    //    		System.out.println(aon);

        	AbstractOperationNode highest=findHighestPriority(ons);
      //  	System.out.println("H"+highest);
        	try
        	{
	        	if (highest.bindRight())
	        	{
	        		highest.r=ons.elementAt(ons.indexOf(highest)+1);
	        		ons.remove(ons.indexOf(highest)+1);
	        	}

	        	if (highest.bindLeft())
	        	{
	        		highest.l=ons.elementAt(ons.indexOf(highest)-1);
	        		ons.remove(ons.indexOf(highest)-1);
	        	}
//	        	for (AbstractOperationNode aon:ons)
	//        		System.out.println(aon);
	        	
	        	if (!highest.bindLeft() && !highest.bindRight()) 
	        		throw new Exception("Expression could not be parsed");
        	}
        	catch(Exception e)
        	{
        		throw new Exception("Syntax error. "+e.getMessage());
        	}


        }


        if(!ons.isEmpty())
        {
        	return ons.get(0);
        }

		throw new Exception("Line could not be parsed.");

    }




	
	
}
