package client;

import java.io.Serializable;
import java.net.SocketAddress;

public class SubjectInfo implements Serializable, Comparable<SubjectInfo>
{
	private static final long serialVersionUID = 1L;

	public int num;
	public String username;
	public String realm;
	public String experimentGroup, experimentRole;
	public boolean inExperiment;

	public boolean isSuspended;

	public SocketAddress socket;


	@Override
	public String toString()
	{
		return username+" "+(inExperiment?experimentGroup+"."+experimentRole:"");
	}

	public SubjectInfo clone()
	{
		SubjectInfo cl=new SubjectInfo();
		cl.num=num;
		cl.username=username;
		cl.realm=realm;
		cl.inExperiment=inExperiment;
		cl.experimentGroup=experimentGroup;
		cl.experimentRole=experimentRole;
		cl.isSuspended=isSuspended;
		return cl;
	}

	@Override
	public int compareTo(SubjectInfo o) {
		return username.compareTo(o.username);
	}

}
