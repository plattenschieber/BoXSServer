package client;

import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import server.Session;

public class ExperimentSessionData implements Serializable
{
	private static final long serialVersionUID = 1L;
	public Map<String, Object> varspace;
	public int num;
	public boolean running;

	@SuppressWarnings("unchecked")
	public ExperimentSessionData(Session experiment, boolean details)
	{
		num=experiment.num;
		varspace=new ConcurrentHashMap(experiment.varspace);

		if (!details)
		{
			Object[] temp=varspace.keySet().toArray();
			
			for (Object s:temp)
				if (((String)s).indexOf('_')!=-1)
						varspace.remove(s);
		}
		running=experiment.running;
	}


}
