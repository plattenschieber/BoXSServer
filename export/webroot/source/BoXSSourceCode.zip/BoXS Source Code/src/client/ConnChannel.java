package client;

import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.concurrent.ConcurrentLinkedQueue;

public abstract class ConnChannel extends Thread{
//	private Socket sin, sout;
	private ObjectOutputStream out;
	private ObjectInputStream in;

	BufferedOutputStream bos;
	OutputStream os;
	
	public ConnChannel(ObjectOutputStream _out, ObjectInputStream _in, BufferedOutputStream _bos, OutputStream _os/*Socket _sin, Socket _sout*/) throws IOException
	{
		bos=_bos;
		os=_os;
/*		sin = _sin;
		sout = _sout;
		out = new ObjectOutputStream(new BufferedOutputStream(sout.getOutputStream()));
		out.flush();
		in = new ObjectInputStream(new BufferedInputStream(sin.getInputStream()));
*/
		out=_out;
		in=_in;
	}
	
	public void close()
	{
		System.out.println("Connection closed");
		try
		{
			in.close();
		//	sin.close();
		}
		catch (Exception e) {
			;
		}
		try
		{
			out.flush();
			out.close();
		}
		catch (Exception e) {
			;
		}
		
		try
		{
			bos.flush();
			bos.close();
		}
		catch (Exception e) {
			;
		}
		
		try
		{
			os.flush();
			os.close();
		}
		catch (Exception e) {
			;
		}
		out=null;
		in=null;
		bos=null;
		os=null;
	}
	
	@Override
	public void run() {
		try
		{
	
			while(true)
			{
				try{
					Object o=in.readObject();
					receive(o);
				}
				catch(EOFException e)
				{
					close();
					return;
				}
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		close();
	}
	
	public abstract void receive(Object o);
	
	final ConcurrentLinkedQueue<Object> sendQueue=new ConcurrentLinkedQueue<Object>();
	
	public void send(Object o)
	{
			new SendThread(o).start();
	}
	
	boolean sending=false;
	
	class SendThread extends Thread
	{ 
		Object o;
		SendThread(Object _o) {o=_o;}
		@Override
		public void run() {
			super.run();

			sendQueue.add(o);
			doSend();
		}
	}
		
		private synchronized void doSend()
		{
			if (!sending) 
			{
				sending=true;
				while (!sendQueue.isEmpty())
				{
					try{
					out.writeObject(sendQueue.poll());
					out.flush();
					bos.flush();
					os.flush();
					}
					catch(Exception e)
					{
						;
					}
				}
				sending=false;
			}
		}
	
}
