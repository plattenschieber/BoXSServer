package client;

import server.ServerClientThread;
import server.Session;

public enum ServerCommand
{
	LOGIN
	{
		@Override
		public void execute(ServerClientThread c, Object o) {
			String[] s=(String[])o;
			c.subinfo.username = s[0];
			c.subinfo.realm = s[1];
			
			if (c.subinfo.username.startsWith("exp:")) c.experimenter=true;
			c.login(s[2]);
		}
	},
	/*
	GET_UPDATE
	{
		@Override
		public void execute(ServerClientThread c, Object arg1)
		{
			Object ret;
			if (c.experimenter)
			{
				// Experimentdaten
				ret=new Object[2];
				if (c.experiment!=null)
				{
					((Object[])ret)[0]=new ExperimentSessionData(c.experiment);
					if (!c.experiment.running)
						c.experiment=null;

				}

				// Subjektdaten
				Vector<SubjectInfo> subinfos=new Vector<SubjectInfo>();

				for (ServerClientThread subject:ServerClientThread.subjectPool)
				{
					if (!subject.subinfo.realm.equals(c.subinfo.realm)) continue;
					SubjectInfo si=subject.subinfo.clone();
					si.inExperiment=subject.experiment!=null;
					si.isSuspended=false;
					subinfos.add(si);
				}

				for (ServerClientThread subject:ServerClientThread.suspendedPool)
				{
					if (!subject.subinfo.realm.equals(c.subinfo.realm)) continue;
					SubjectInfo si=subject.subinfo.clone();
					si.inExperiment=subject.experiment!=null;
					si.isSuspended=true;
					subinfos.add(si);
				}

				((Object[])ret)[1]=subinfos;
			}
			else
			{
				ret="";
				if (!c.updates.isEmpty() && c.experimentParser.sendUpdateToClients)
				{
					c.lastUpdates.clear();
					c.lastUpdates.addAll(c.updates);

					for (String s:c.updates)
						ret=ret+s+"\n";
					c.updates.clear();
				}
			}

			c.send(ret);
		}
	},*/

	START_EXPERIMENT
	{
		@Override
		public void execute(ServerClientThread c, Object o)
		{
			if (c.experiment==null || !c.experiment.running)
			{
				Session es=new Session(c,(String)o);
				es.start();
			}
		/*	else
			{
				c.experiment.populate();
			}*/
			c.update();
		}
	},


	START_EXPERIMENT_AUTORUN
	{
		@Override
		public void execute(ServerClientThread c, Object o)
		{
			if (c.experiment==null || !c.experiment.running)
			{
				if (ServerClientThread.autorunPrograms.containsKey(c.subinfo.realm))
				{
					ServerClientThread.autorunPrograms.remove(c.subinfo.realm);
					ServerClientThread.autorunProgramsExperimenter.remove(c.subinfo.realm);
				}
				else
				{
					ServerClientThread.autorunPrograms.put(c.subinfo.realm, (String)o);
					ServerClientThread.autorunProgramsExperimenter.put(c.subinfo.realm, c);
				}
			}
		/*	else
			{
				c.experiment.populate();
			}*/
			c.update();
		}
	},


	SUBMIT_VALUE
	{
		@Override
		public void execute(ServerClientThread c, Object o)
		{
			Object[] temp=(Object[])o;

			try
			{
				boolean ret=c.experimentParser.submitValue((String)temp[0],temp[1],((Long)temp[2]).longValue());
				c.send(new ServerSideValidInfo(ret));
				c.notifyExperimenter();
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}

		}
	},


	SET_READY
	{
		@Override
		public void execute(ServerClientThread c, Object o)
		{
			c.ready=((String)o).equals("yes");
		}
	},
	

	SET_DETAILS
	{
		@Override
		public void execute(ServerClientThread c, Object o)
		{
			c.details=((Integer)o)==1;
			c.update();
		}
	},



	SEND_EXPERIMENT
	{
		@Override
		public void execute(ServerClientThread c, Object o)
		{
			System.out.println("received send request: experiment="+c.experiment);
			
			if (c.experiment!=null)
			{
				c.experiment.sendSessionDataByMail("send requested");
			}
		}
	},
	

	AUTOSEND_EXPERIMENT
	{
		@Override
		public void execute(ServerClientThread c, Object o)
		{
			System.out.println("received autosend request: experiment="+c.experiment);
			
			if (c.experiment!=null)
			{
				c.experiment.autosend=!c.experiment.autosend;
			}
		}
	},


	KILL_SUBJECT
	{
		@Override
		public void execute(ServerClientThread c, Object o)
		{
			SubjectInfo si=(SubjectInfo)o;
			System.out.println("Kill subject "+si.username);
			ServerClientThread killsct=null;
			for (ServerClientThread sct:ServerClientThread.subjectPool)
				if (si.username.equals(sct.subinfo.username))
					killsct=sct;
			if (killsct!=null) 
			{
//				killsct.experimentParser=null;
				killsct.close();
				if (ServerClientThread.suspendedPool.contains(killsct))
					ServerClientThread.suspendedPool.remove(killsct);
					
			}

		}
	},

	
	CANCEL_EXPERIMENT
	{
		@Override
		public void execute(ServerClientThread c, Object o)
		{
			if (c.experiment!=null)
			{
				c.experiment.sendSessionDataByMail("experiment cancelled");
				c.experiment.cancelExperiment();
				c.update();
			}
		}
	};

	public abstract void execute(ServerClientThread c, Object o);
}

