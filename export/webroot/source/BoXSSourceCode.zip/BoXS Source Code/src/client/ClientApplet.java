package client;
import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.KeyboardFocusManager;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyEvent;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;
import java.util.concurrent.ConcurrentLinkedQueue;

import javax.media.Manager;
import javax.media.MediaLocator;
import javax.media.Player;
import javax.swing.AbstractAction;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.border.LineBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.html.parser.ParserDelegator;



public class ClientApplet extends Applet {
	private static final String HTML_FOOTER = "</body></html>";

	private Font FONT;

	private static final long serialVersionUID = 1L;


	boolean serverSideValid=false;
	public String username, realm;

	public JPanel mainPanel=new JPanel();
	
	public ClientConnection cc;
	public boolean experimenter;

	boolean isUpdating=false;
	Timer t=null;
	Date lastResize=new Date();
	String lastUpdate="";
	Date lastUpdateTime=null;

	HashMap<Integer, Component> componentCache=new HashMap<Integer, Component>();
	HashMap<Component, Rectangle> manualLayoutCache=new HashMap<Component, Rectangle>();
	LinkedList<DocumentListener> oldDocumentListeners=new LinkedList<DocumentListener>();

	public boolean waitButtonPressed;
	HashMap<String, String> defaults=new HashMap<String, String>();


	boolean automaticlayout=true;

	boolean internalresize=false;

	LinkedList<JButton> waitButtons=new LinkedList<JButton>();
	Vector<Object> inputFulfilled=new Vector<Object>();
	
	
	
	public void init()
	{
		initFontsize();
		setLayout(new BorderLayout());
		mainPanel.setBackground(Color.white);
		mainPanel.setOpaque(true);
		mainPanel.setLayout(new BoxLayout(mainPanel,BoxLayout.Y_AXIS));
	}


	@Override
	public void start()
	{
		super.start();
		initFontsize();

		String _host="localhost";
		int _port=58000;
		try{
			if (getParameter("host")!=null) _host=getParameter("host");
			if (getParameter("port")!=null) _port=Integer.parseInt(getParameter("port"));
			if (getParameter("username")!=null) username=getParameter("username");
			if (getParameter("realm")!=null) realm=getParameter("realm");
			if (getParameter("showstartscreen")!=null) showStartScreen=Boolean.parseBoolean(getParameter("showstartscreen"));
		} catch(Exception e)
		{
			;
		}
		final String host=_host;
		final int port=_port;

		String _password=null;

		if (username==null)
		{
			String text=JOptionPane.showInputDialog(null, "Please enter your user name", username);
			username=(text!=null)?text:"";
		}
		if (realm==null)
		{
			String text=JOptionPane.showInputDialog(null, "Please enter the realm", realm);
			realm=(text!=null)?text:"";
		}

		experimenter=username.startsWith("exp");

		if (experimenter)
		{
			String text=JOptionPane.showInputDialog(null, "Please enter your password", _password);
			_password=(text!=null)?text:"";
		}

		final String password=_password;


		System.out.println("getW"+getWidth());
		if (!experimenter)
		{
			add(new JScrollPane(mainPanel, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER),BorderLayout.CENTER);
			JPanel temp1=new JPanel();
			temp1.setPreferredSize(new Dimension(1,getHeight()/50));
			temp1.setBackground(Color.white);
			add(temp1,BorderLayout.NORTH);
		}
		else
		{
			add(mainPanel,BorderLayout.CENTER);
			startExperimenter();
		}
		
		addComponentListener(new ComponentAdapter()
		{
			@Override
			public void componentResized(ComponentEvent e)
			{
				super.componentResized(e);
				
				if (!username.startsWith("exp"))
				{	// Client update
					initFontsize();

					if (!isUpdating)
					{
						isUpdating=true;
						if (t!=null)
						{
							t.cancel();
							t=null;
						}

						if (!internalresize) executeSubjectUpdate(lastUpdate);

						t=new Timer();
						t.schedule(new TimerTask()
						{
							@Override
							public void run()
							{
								SwingUtilities.invokeLater(new Runnable()
								{
									public void run() {
										isUpdating=false;
									};
								});
							}

						}, 500);
					}
				}
			}

		});
		


		final ClientApplet thisca=this;

		if (!experimenter)
		{
			mainPanel.add(new JLabel("Connecting to server..."));
			mainPanel.doLayout(); mainPanel.repaint();
		}
		
		// connect
		new Thread()
		{
		public void run() {

			boolean connected=false;
			
			while (!connected)
			{
				// Connect
				try
				{
					Socket sa=new Socket(host, port);
					ObjectInputStream ois=new ObjectInputStream(new BufferedInputStream(sa.getInputStream(),4000000));
			//	ObjectInputStream ois=new ObjectInputStream(new BufferedInputStream(sa.getInputStream()));
//					ObjectInputStream ois=new ObjectInputStream(sa.getInputStream());
					int num=((Integer)ois.readObject()).intValue();
					
					Socket sb=new Socket(host, port+1);
	//				ObjectOutputStream oos=new ObjectOutputStream(sb.getOutputStream());
					BufferedOutputStream bos=new BufferedOutputStream(sb.getOutputStream(),1000000);
		//			BufferedOutputStream bos=new BufferedOutputStream(sb.getOutputStream());
					ObjectOutputStream oos=new ObjectOutputStream(bos);
					oos.writeObject(new Integer(num));
					oos.flush();
					
					cc=new ClientConnection(oos, ois,thisca, bos, sb.getOutputStream());
					cc.start();
					cc.loginToServer(username, realm, password);
					System.out.println("Connected to server");
					if (!experimenter)
						executeSubjectUpdate("");
					
					connected=true;
				}
				catch(Exception e)
				{
					e.printStackTrace();
					mainPanel.add(new JLabel("Error logging in to server "+host+":"+port+" "+e.getLocalizedMessage()));
					mainPanel.doLayout(); mainPanel.repaint();
				try {
						sleep(5000);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
				}
			}
		};	
		}.start();
	}

	private void initFontsize() {
		int fontsize=Math.min(14, getWidth()/35);
		if (fontsize<8) fontsize=8;
		FONT = new Font("Arial",Font.PLAIN,fontsize);
	}


	public void makeBorder(JComponent c)
	{
		c.setBorder(new LineBorder(Color.white,FONT.getSize()/4));
	}


	
	HashMap<JScrollPane,JTextArea> jsp_to_jta=new HashMap<JScrollPane, JTextArea>();
	
	public boolean showStartScreen=true;
	boolean layoutspecified=false;
	
	boolean updating=false; 

	ConcurrentLinkedQueue<String> updates=new ConcurrentLinkedQueue<String>();
	
	
	public void executeSubjectUpdate(final String _update)
	{
		updates.add(_update);
		_executeUpdate();
	}


	private void _executeUpdate() {
		if (updates.isEmpty()) return;
		
		if (!updating)
		{
			updating=true;
			SwingUtilities.invokeLater(new Runnable() {
				
				@Override
				public void run() {
					if (!updates.isEmpty()) 
						__executeSubjectUpdate(updates.poll());
					updating=false;
				}
			});
		}
		else
		{
			System.out.println("Delaying update display");
			new Timer().schedule(new TimerTask() {
				@Override
				public void run() {
					_executeUpdate();
				}
			}, 500);

		}
	}
	
	
	private Component firstcomp=null;
	
	private void __executeSubjectUpdate(String _update)
	{
		layoutspecified=false;
		defaults.clear();
		String update=_update;
		
		boolean changed=false, majorchange=false;
		waitButtonPressed=false;
		
		lastUpdate=update;
		if (update.equals("") || update.startsWith("finish"))
		{
			customstyle=null;
			if (showStartScreen)
				update="-1@display(\"<br><h1>Bonn Experiment System</h1>Framework for conducting laboratory and field experiments<br>in economic and social science<br><br><br><br><table width=100%><tr><td>Mirko Seithe<br>mseithe@uni-bonn.de<br>Bonn Graduate School of Economics<br>University of Bonn</td><td> <img src='http://boxs.uni-bonn.de/bonn.png'></td></tr></table>\")";
			else
				update="-1@display(\"<br>Please wait.\")";
			componentCache.clear();
		}

		// System.out.println("|"+update+"|");

		JButton btnSS=new JButton("Screenshot");
		if (getParameter("screenshot")!=null)
		{
			btnSS.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					Utils.makeComponentShot(mainPanel);
				}
			});
			add(btnSS, BorderLayout.SOUTH);
		}

		firstcomp=null;
		

		Vector<Component> desiredComponents=new Vector<Component>();
		inputFulfilled.clear();

		waitButtons.clear();
		int linenum=0;
		String[] updatelines=update.split("\n");
		for (String _line:updatelines)
		{
			linenum=Integer.parseInt(_line.substring(0,_line.indexOf("@")));
			String line=_line.substring(_line.indexOf("@")+1);
			try
			{
				String command=line.substring(0,line.indexOf("(")).trim();
				String param=line.substring(line.indexOf("(")+1, line.lastIndexOf(")")).trim();
				Vector<String> paramparts=client.Utils.splitByComma(param);
				lastUpdateTime=new Date();

				if (command.equals("clear"))
				{
					desiredComponents.removeAllElements();
					manualLayoutCache.clear();
					mainPanel.removeAll();
					componentCache.clear();
				}
				
				if (command.equals("display"))
				{
					if (!layoutspecified) setLayoutAutomatic(true);
					String content=paramparts.get(0);
					if (content.startsWith("\""))
						content=content.substring(content.indexOf("\"")+1, content.lastIndexOf("\""));


					JLabel jl;
					if (componentCache.containsKey(linenum) && componentCache.get(linenum) instanceof JLabel
							&& !desiredComponents.contains(componentCache.get(linenum)))
					{
						jl=(JLabel)componentCache.get(linenum);
						int temp=jl.getPreferredSize().height;
						jl.setText("<html>"+getStyle()+"<body>"+content+HTML_FOOTER);
						jl.validate();
						jl.doLayout();
						if (temp!=jl.getPreferredSize().height)
							changed=true;
					}
					else
					{
						jl=new JLabel("<html>"+getStyle()+"<body>"+content+HTML_FOOTER);
						makeBorder(jl);
						jl.setFont(FONT);
						componentCache.put(linenum, jl);
					}
					
					if(!automaticlayout&&paramparts.size()>=5)
					{
						manualLayoutCache.put(jl,new Rectangle(
								(int)Utils.toDouble(paramparts.get(1)), 
								(int)Utils.toDouble(paramparts.get(2)), 
								(int)Utils.toDouble(paramparts.get(3)), 
								(int)Utils.toDouble(paramparts.get(4))));
					}

					desiredComponents.add(jl);
				}


				else if (command.equals("video"))
				{
					String content=param.substring(1,param.length()-1);
					URL url=new URL(getDocumentBase(),content);
					String extname=url.toExternalForm();
					MediaLocator mloc=new MediaLocator(extname);

					try {
						Player p=Manager.createRealizedPlayer(mloc);
						Component video=p.getVisualComponent();
						desiredComponents.add(video);
						p.start();
					} catch (Exception e2) {
						e2.printStackTrace();
					}
				}



				else if (command.equals("wait"))
				{
					if (!layoutspecified) setLayoutAutomatic(true);
					String content=paramparts.get(1), pressedcontent=paramparts.get(2);
					if (content.startsWith("\""))
						content=param.substring(param.indexOf("\"")+1, param.lastIndexOf("\""));
					if (pressedcontent.startsWith("\""))
						pressedcontent=param.substring(param.indexOf("\"")+1, param.lastIndexOf("\""));

					JButton jb;

					if (componentCache.containsKey(linenum) && componentCache.get(linenum) instanceof JButton)
					{
						jb=(JButton)componentCache.get(linenum);
						jb.setText("<html>"+getStyle()+"<body>"+content+HTML_FOOTER);
						for (ActionListener al:jb.getActionListeners())
							jb.removeActionListener(al);
					}
					else
					{
						//System.out.println();
						//System.out.println(getStyle());
						//System.out.println(content);
						//System.out.println(line);
						jb=new JButton("<html>"+getStyle()+"<body>"+content+HTML_FOOTER);
						//jb=new JButton("<html><body>"+content+HTML_FOOTER);
						//jb=new JButton("Hallo");
						jb.setFont(FONT);
						jb.setMaximumSize(new Dimension(FONT.getSize()*20,FONT.getSize()+8));
						jb.setAlignmentX(Component.LEFT_ALIGNMENT);
						componentCache.put(linenum, jb);
					}
					
					jb.addActionListener(new ContinueButtonListener(this,jb,cc,paramparts.get(0).trim(),pressedcontent.trim(), lastUpdateTime));

					enableFocusTraversal(jb);
						
					if(!automaticlayout&&paramparts.size()>=7)
					{
						manualLayoutCache.put(jb,new Rectangle(
								(int)Utils.toDouble(paramparts.get(3)), 
								(int)Utils.toDouble(paramparts.get(4)), 
								(int)Utils.toDouble(paramparts.get(5)), 
								(int)Utils.toDouble(paramparts.get(6))));
					}

					
					desiredComponents.add(jb);
					waitButtons.add(jb);
				}

				else if (command.equals("inputNumber") || command.equals("inputString") || command.equals("inputNumberNC") || command.equals("inputStringNC"))
				{
					boolean number=command.equals("inputNumber") || command.equals("inputNumberNC") ;
					if (!layoutspecified) setLayoutAutomatic(true);
					JPanel jp=null;
					JScrollPane jsp;

					if (automaticlayout)
					{
						if (componentCache.containsKey(linenum) && componentCache.get(linenum) instanceof JPanel
								&& ((JPanel)componentCache.get(linenum)).getComponent(0) instanceof JScrollPane
								&& !desiredComponents.contains(componentCache.get(linenum)))
						{
							jp=(JPanel)componentCache.get(linenum);
							jsp=(JScrollPane)jp.getComponent(0);
						}
						else
						{
							jp=new JPanel(new BorderLayout());
							JTextArea jtf=new JTextArea();
							jtf.setFont(FONT);
							jp.setAlignmentX(Component.LEFT_ALIGNMENT);
							jtf.setAlignmentX(Component.LEFT_ALIGNMENT);
						//	jtf.setPreferredSize(new Dimension(FONT.getSize()*20,(int)(FONT.getSize()*2)));
							jtf.setLineWrap(true);
							jp.setMaximumSize(new Dimension(Math.min(600, getWidth()-100),(int)(FONT.getSize()*2)));
							jp.setBackground(Color.white);
							jp.setOpaque(true);
							jsp=new JScrollPane(jtf, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
							jsp.setMaximumSize(new Dimension(Math.min(600, getWidth()-100),(int)(FONT.getSize()*2)));
							jsp.setPreferredSize(new Dimension(Math.min(600, getWidth()-100),(int)(FONT.getSize()*2)));
							jsp_to_jta.put(jsp, jtf);
							//jsp.setBorder(new LineBorder(Color.black,1));
							jp.add(jsp, BorderLayout.WEST);
							jtf.setFocusTraversalKeysEnabled(true);
							enableFocusTraversal(jtf); 
							if (number) disableenter(jtf); 
							 
						
							componentCache.put(linenum, jp);
						}
					}
					else
					{
						if (componentCache.containsKey(linenum) && componentCache.get(linenum) instanceof JScrollPane
								&& !desiredComponents.contains(componentCache.get(linenum)))
						{
							jsp=(JScrollPane)componentCache.get(linenum);
						}
						else
						{
							JTextArea jtf=new JTextArea();
							jtf.setFont(FONT);
							jtf.setAlignmentX(Component.LEFT_ALIGNMENT);
							jtf.setLineWrap(true);
							jsp=new JScrollPane(jtf, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
							jsp_to_jta.put(jsp, jtf);
							if (number) disableenter(jtf); 
							componentCache.put(linenum, jsp);
						}	
					}
					InputTextFieldHandler itfh;
					boolean valid=false;
					DocumentListener remdl=null;
					JTextArea jtf =jsp_to_jta.get(jsp);
					enableFocusTraversal(jtf);
					for (DocumentListener dl:oldDocumentListeners)
					{
						if (dl instanceof InputTextFieldHandler)
						{
							InputTextFieldHandler itfh2=(InputTextFieldHandler)dl;
							if (jtf==itfh2.jtf)
							{
								valid=itfh2.valid;
								remdl=dl;
							}
						}
					}

					
					String varname=paramparts.firstElement().substring(1,paramparts.firstElement().length()-1);

					if (command.equals("inputNumber") || command.equals("inputNumberNC"))
						itfh=new InputTextFieldHandler(jtf,varname,Double.class,lastUpdateTime);
					else
						itfh=new InputTextFieldHandler(jtf,varname,String.class,lastUpdateTime);

					if (defaults.containsKey(varname) && !isDisplayed(jsp) && !isDisplayed(jp)  )
					{
						jtf.setText(defaults.get(varname));
						itfh.upd();
					}
					
					itfh.valid=valid;
					
					for (DocumentListener dl:oldDocumentListeners)
						jtf.getDocument().removeDocumentListener(dl);
					if (remdl!=null)
						oldDocumentListeners.remove(remdl);

					jtf.getDocument().addDocumentListener(itfh);
					oldDocumentListeners.add(itfh);

					if (command.equals("inputNumber") || command.equals("inputString"))
						inputFulfilled.add(itfh);
					
					if(!automaticlayout&&paramparts.size()>=5)
					{			
						desiredComponents.add(jsp);
						
						Rectangle rectangle = new Rectangle(
								(int)Utils.toDouble(paramparts.get(1)), 
								(int)Utils.toDouble(paramparts.get(2)), 
								(int)Utils.toDouble(paramparts.get(3)), 
								(int)Utils.toDouble(paramparts.get(4)));
						jsp.setPreferredSize(new Dimension(rectangle.width, rectangle.height));
						jsp.setMaximumSize(new Dimension(rectangle.width, rectangle.height));
						manualLayoutCache.put(jsp,rectangle);
					}
					else
						desiredComponents.add(jp);
				}

				else if (command.equals("choice") || command.equals("choiceNC"))
				{
					if (!layoutspecified) setLayoutAutomatic(true);
					JPanel jp;					
					int optioncount=paramparts.size();
					if (!automaticlayout)
						optioncount-=4;
					
					if (componentCache.containsKey(linenum) && componentCache.get(linenum) instanceof JPanel
							&& !desiredComponents.contains(componentCache.get(linenum)))
					{
						jp=(JPanel)componentCache.get(linenum);
					}
					else
					{
						jp=new JPanel();
						jp.setLayout(new BoxLayout(jp,BoxLayout.X_AXIS));
						makeBorder(jp);
						
						String var=null;
						ButtonGroup bg=new ButtonGroup();

						jp.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
						

						boolean defex=false;
						
						for (int i=0; i<optioncount; i++)
						{
							String _val=paramparts.get(i);
							if (var==null) var=_val;
							else
							{
								Object val;
								val=_val.trim();
								if (((String)val).startsWith("\""))
									val=((String)val).substring(1,((String)val).length()-1);
								else
									val=Utils.toDouble(((String)val));


								if (val.toString().startsWith("_"))
								{
									JLabel jl=new JLabel("<html>"+getStyle()+"<body>"+val.toString().substring(1)+HTML_FOOTER);
									jl.setFont(FONT);
									jl.setBackground(Color.white);
									jl.setAlignmentX(Component.LEFT_ALIGNMENT);
									jp.add(jl);
									
								}
								else
								{
									JRadioButton jrb=new JRadioButton("<html>"+getStyle()+"<body>"+val.toString()+HTML_FOOTER);
									jrb.setFont(FONT);
									jrb.setBackground(Color.white);
									jrb.setAlignmentX(Component.LEFT_ALIGNMENT);
									jrb.addActionListener(new RBListener(var,val,lastUpdateTime));
									jrb.setFocusTraversalKeysEnabled(true);

									bg.add(jrb);
									jp.add(jrb);
									enableFocusTraversal(jrb);
									
									String varname=paramparts.firstElement().substring(1,paramparts.firstElement().length()-1);
									if (defaults.containsKey(varname) && !isDisplayed(jp))
									{
										defex=true;
										Object o=defaults.get(varname);
										if (((String)o).equals(val.toString()))
										{
											jrb.setSelected(true);
										}
									}

								}
							}
						}

						jp.setAlignmentX(Component.LEFT_ALIGNMENT);
						jp.setMaximumSize(new Dimension(getWidth(),(int)(FONT.getSize()*2*2)));
						jp.setMinimumSize(new Dimension(0,(int)(FONT.getSize()*2)));
						jp.setBackground(Color.white);
						jp.setOpaque(true);
						jp.invalidate();
						jp.validate();
						jp.doLayout();

						if (command.equals("choice"))
							inputFulfilled.add(bg);
						if (defex)
							checkFulfilled();

						componentCache.put(linenum, jp);
					}
					

					if(!automaticlayout&&optioncount>=0)
					{
						manualLayoutCache.put(jp,new Rectangle(
								(int)Utils.toDouble(paramparts.get(paramparts.size()-4)), 
								(int)Utils.toDouble(paramparts.get(paramparts.size()-3)), 
								(int)Utils.toDouble(paramparts.get(paramparts.size()-2)), 
								(int)Utils.toDouble(paramparts.get(paramparts.size()-1))));
					}
					desiredComponents.add(jp);
				}


				else if (command.equals("button") )
				{
					if (!layoutspecified) setLayoutAutomatic(true);
					JPanel jp;
					JButton jab;

					if (componentCache.containsKey(linenum) && componentCache.get(linenum) instanceof JPanel
							&& ((JPanel)componentCache.get(linenum)).getComponent(0) instanceof JButton
							&& !desiredComponents.contains(componentCache.get(linenum)))
					{
						jp=(JPanel)componentCache.get(linenum);
						jab=(JButton)jp.getComponent(0);
					}
					else
					{
						jp=new JPanel();
						jab=new JButton();
						jab.setFont(FONT);
						jab.setMinimumSize(new Dimension(FONT.getSize()*10,FONT.getSize()+8));
						jab.setMaximumSize(new Dimension(FONT.getSize()*10,FONT.getSize()+8));
						jab.setAlignmentX(Component.LEFT_ALIGNMENT);
						makeBorder(jp);
						jp.add(jab);
						jp.setAlignmentX(Component.LEFT_ALIGNMENT);
						jp.setMaximumSize(new Dimension(1000,(int)(FONT.getSize()+12)));
						jp.setMinimumSize(new Dimension(0,(int)(FONT.getSize()+12)));
						jp.setBackground(Color.white);
						jp.setLayout(new BoxLayout(jp,BoxLayout.X_AXIS));
						jp.setOpaque(true);
						componentCache.put(linenum, jp);
					}
					waitButtons.add(jab);
					jab.setFocusTraversalKeysEnabled(true);


					String var=paramparts.get(0);
					String label=paramparts.get(1);

					if (label.startsWith("\""))
						label=label.substring(label.indexOf("\"")+1, label.lastIndexOf("\""));

					jab.setText("<html>"+getStyle()+"<body>"+label+HTML_FOOTER);


					ActionListener[] actionListeners = jab.getActionListeners();
					for (ActionListener al:actionListeners)
						jab.removeActionListener(al);

					jab.addActionListener(new ABListener(var,lastUpdateTime));
					enableFocusTraversal(jab);

					if(!automaticlayout&&paramparts.size()>=6)
					{
						manualLayoutCache.put(jp,new Rectangle(
								(int)Utils.toDouble(paramparts.get(2)), 
								(int)Utils.toDouble(paramparts.get(3)), 
								(int)Utils.toDouble(paramparts.get(4)), 
								(int)Utils.toDouble(paramparts.get(5))));
					}

					desiredComponents.add(jp);
				}
			
				else if (command.equals("checkbox"))
				{
					if (!layoutspecified) setLayoutAutomatic(true);
					JPanel jp;
					JCheckBox jab;

					if (componentCache.containsKey(linenum) && componentCache.get(linenum) instanceof JPanel
							&& ((JPanel)componentCache.get(linenum)).getComponent(0) instanceof JCheckBox
							&& !desiredComponents.contains(componentCache.get(linenum)))
					{
						jp=(JPanel)componentCache.get(linenum);
						jab=(JCheckBox)jp.getComponent(0);
					}
					else
					{
						jp=new JPanel();
						jab=new JCheckBox();
						jab.setFont(FONT);
						jab.setMinimumSize(new Dimension(FONT.getSize()*10,FONT.getSize()+8));
						jab.setMaximumSize(new Dimension(FONT.getSize()*10,FONT.getSize()+8));
						jab.setAlignmentX(Component.LEFT_ALIGNMENT);
						jab.setOpaque(false);
						makeBorder(jp);
						jp.add(jab);
						jp.setAlignmentX(Component.LEFT_ALIGNMENT);
						jp.setMaximumSize(new Dimension(1000,(int)(FONT.getSize()+12)));
						jp.setMinimumSize(new Dimension(0,(int)(FONT.getSize()+12)));
						jp.setBackground(Color.white);
						jp.setLayout(new BoxLayout(jp,BoxLayout.X_AXIS));
						jp.setOpaque(false);
						componentCache.put(linenum, jp);
					}
					jab.setFocusTraversalKeysEnabled(true);
					enableFocusTraversal(jab);

					String var=paramparts.get(0);
					String label=paramparts.get(1);

					String varname=paramparts.firstElement().substring(1,paramparts.firstElement().length()-1);
					if (defaults.containsKey(varname)&& !isDisplayed(jp))
					{
						Object o=defaults.get(varname);
						if (Utils.toDouble((String)o)!=0)
						{
							jab.setSelected(true);
						}
					}

					
					if (label.startsWith("\""))
						label=label.substring(label.indexOf("\"")+1, label.lastIndexOf("\""));

					jab.setText("<html>"+getStyle()+"<body>"+label+HTML_FOOTER);


					ActionListener[] actionListeners = jab.getActionListeners();
					for (ActionListener al:actionListeners)
						jab.removeActionListener(al);

					jab.addActionListener(new CBListener(var,jab,lastUpdateTime));

					if(!automaticlayout&&paramparts.size()>=6)
					{
						manualLayoutCache.put(jp,new Rectangle(
								(int)Utils.toDouble(paramparts.get(2)), 
								(int)Utils.toDouble(paramparts.get(3)), 
								(int)Utils.toDouble(paramparts.get(4)), 
								(int)Utils.toDouble(paramparts.get(5))));
					}

					desiredComponents.add(jp);
				}

				else if (command.equals("style"))
				{
					String content=param;
					if (param.startsWith("\""))
						content=param.substring(param.indexOf("\"")+1, param.lastIndexOf("\""));
					customstyle=content;
				}
				else if (command.equals("setdefault"))
				{
					String key=paramparts.get(0);
					if (paramparts.size()>1)
					{
						String content=paramparts.get(1);
						if (paramparts.get(1).startsWith("\""))
							content=paramparts.get(1).substring(paramparts.get(1).indexOf("\"")+1, paramparts.get(1).lastIndexOf("\""));
						defaults.put(key, content.replaceAll("\\\\n", "\n"));
					}
					else if (defaults.containsKey(key))
						defaults.remove(key);
				}
				else if (command.equals("manualLayout"))
				{
					setLayoutAutomatic(false);
				}

			}
			catch(Exception e)
			{
				e.printStackTrace();

			}
		}

		mainPanel.setFocusCycleRoot(true);

		// 1) remove components from mainPanel which are no longer desired
		LinkedList<Component> deleteComponents=new LinkedList<Component>();
		for (Component c:mainPanel.getComponents())
			if (!desiredComponents.contains(c))
				deleteComponents.add(c);
		//System.out.println("deleting components: "+deleteComponents.size());
		for (Component c:deleteComponents)
		{
			mainPanel.remove(c);
			majorchange=true;
		}

		// add missing components
		int prevCompPos=-1;
		for (Component c:desiredComponents)
		{
			boolean exists=false;

			for (int i=0; i<mainPanel.getComponents().length; i++)
			{
				if (mainPanel.getComponents()[i]==c)
				{
					exists=true;
					prevCompPos=i;
				}
			}


			if (!exists)
			{
//				System.out.println("adding component");
				mainPanel.add(c,prevCompPos+1);
				majorchange=true;
				prevCompPos++;
			}
			
			if(!automaticlayout && manualLayoutCache.containsKey(c))
				c.setBounds(manualLayoutCache.get(c));
		}
		
		

		if (majorchange)
			serverSideValid=true;

		checkFulfilled();
		if (changed || majorchange)
		{
		validate();
		doLayout();
		invalidate();
		repaint();
			if (firstcomp!=null)
			{
				firstcomp.requestFocusInWindow();
				firstcomp.requestFocus();
			}
		}
		
		if (cc!=null && !_update.equals("") && !_update.equals("finish"))
		{
			Object[] o={"_clientdisplaytime"+linenum,new Double(new Date().getTime()),new Long(new Date().getTime())};
			cc.send(ServerCommand.SUBMIT_VALUE, o);
			Object[] o2={"_clientwidth",new Double(mainPanel.getWidth()),new Long(new Date().getTime())};
			cc.send(ServerCommand.SUBMIT_VALUE, o2);
			Object[] o3={"_clientheight",new Double(mainPanel.getHeight()),new Long(new Date().getTime())};
			cc.send(ServerCommand.SUBMIT_VALUE, o3);
		}
	}


	private void enableFocusTraversal(final Component jtf) {
		if (firstcomp==null) firstcomp=jtf;
		
		jtf.setFocusable(true);
		jtf.setFocusTraversalKeysEnabled(true);
		
		Set<KeyStroke> newForwardKeys = new HashSet<KeyStroke>();
		newForwardKeys.add(KeyStroke.getKeyStroke(KeyEvent.VK_TAB, 0));
		Set<KeyStroke> newBackwardKeys = new HashSet<KeyStroke>();
		newBackwardKeys.add(KeyStroke.getKeyStroke(KeyEvent.VK_TAB, KeyEvent.SHIFT_DOWN_MASK));
		jtf.setFocusTraversalKeys(KeyboardFocusManager.FORWARD_TRAVERSAL_KEYS,
		    newForwardKeys);
		jtf.setFocusTraversalKeys(KeyboardFocusManager.BACKWARD_TRAVERSAL_KEYS,
			    newBackwardKeys);


		/*
		AbstractAction tabAction = new AbstractAction() {  
			private static final long serialVersionUID = 1L;
			public void actionPerformed(ActionEvent e) {
				//jtf.getFo
		    }  
		};  
		KeyStroke tabKey = KeyStroke.getKeyStroke("TAB");  
	//	jtf.getInputMap().put(tabKey, tabAction);*/
	}
	

	private void disableenter(JTextArea jtf) {
		AbstractAction tabAction = new AbstractAction() {  
			private static final long serialVersionUID = 1L;
		    public void actionPerformed(ActionEvent e) {  
		    }  
		};  
		KeyStroke tabKey = KeyStroke.getKeyStroke("ENTER");  
		jtf.getInputMap().put(tabKey, tabAction);
		tabKey = KeyStroke.getKeyStroke("RETURN");  
		jtf.getInputMap().put(tabKey, tabAction);
	}
	
	private boolean isDisplayed(Component jp) {
		for (Component c:mainPanel.getComponents())
			if (c==jp) return true;
		return false;
	}

	private void setLayoutAutomatic(boolean b) {
		layoutspecified=true;
		if (automaticlayout==b) return;
		automaticlayout=b;
		mainPanel.setLayout(automaticlayout?new BoxLayout(mainPanel,BoxLayout.Y_AXIS):null);
	}
	public synchronized void checkFulfilled()
	{
		boolean clientSideValid=true;
		for (Object b:inputFulfilled)
		{
			if (b instanceof InputTextFieldHandler && !((InputTextFieldHandler)b).valid)
			{
				clientSideValid=false;
			}
			else if (b instanceof ButtonGroup)
			{
				if (((ButtonGroup) b).getSelection()==null) clientSideValid=false;
			}
		}
		
		for (JButton wb:waitButtons)
			wb.setEnabled(clientSideValid && serverSideValid && !waitButtonPressed);
	}


	String customstyle=null;


	public String getStyle()
	{
		// workaround for Java-Bug
		@SuppressWarnings("unused")
		ParserDelegator workaround = new ParserDelegator();
		// http://forums.oracle.com/forums/thread.jspa?messageID=7432921
		
		String t="";
		t+="<style>";
		
		if (customstyle!=null && !customstyle.equals(""))
		{
			t+=customstyle;
		}
		else
		{
			t+="body{ padding: 0px; font-size: "+Math.round(FONT.getSize()*0.8)+"px; }";
			t+="h1{font-size: 130%; margin-top: 0px; margin-bottom: 3px; font-weight: normal; }";
			t+="h2{font-size: 115%; margin-top: 0px; margin-bottom: 3px; font-weight: normal; }";
			t+="table{background-color: #eeeeee; border:solid; border-width:1px; border-color: #000000; margin:5px; margin-left:10px;}";
			t+="td,th{padding:5px;text-align: center;}";
			t+="th{background-color: #dddddd; }";
		}
		
		t+="</style>";
		
		//System.out.println("#"+t+"#");
		return t;
	}


	@SuppressWarnings("unchecked")
	class InputTextFieldHandler implements DocumentListener
	{
		String varname;
		Class type;
		JTextArea jtf;
		Date starttime;

		InputTextFieldHandler(JTextArea _jtf,  String _varname, Class _type, Date _startTime)
		{
			varname=_varname;
			type=_type;
			jtf=_jtf;
			starttime=_startTime;
		}

		@Override
		public void changedUpdate(DocumentEvent arg0)
		{
			upd();
		}

		@Override
		public void insertUpdate(DocumentEvent arg0)
		{
			upd();
		}

		@Override
		public void removeUpdate(DocumentEvent arg0)
		{
			upd();
		}


		boolean valid=false;

		void upd()
		{
					try
					{

						Object[] o={varname,type==Double.class?
								new Double(jtf.getText().replaceAll(",", ".")):jtf.getText(),
								new Long(new Date().getTime() - starttime.getTime())};
						serverSideValid=false;
						jtf.setBackground(Color.white);
						cc.send(ServerCommand.SUBMIT_VALUE, o);
						valid=true;
						
						
						
/*							Boolean b=(Boolean)cc.send();
							if (b!=true) throw new Exception("");
							valid=true;
*/		
					}
					catch(Exception e)
					{
						jtf.setBackground(new Color(255,220,220));
						valid=false;
						//e.printStackTrace();
					}
					checkFulfilled();
				}
		
	}

	private void startExperimenter()
	{
		remove(mainPanel);
		mainPanel=new ExperimenterPanel(this);
		add(mainPanel,BorderLayout.CENTER);

	}



	public ImageIcon loadImage(String name) {
		String path = name;
		int MAX_IMAGE_SIZE = 2400;  //Change this to the size of
									 //your biggest image, in bytes.
		int count = 0;
		BufferedInputStream imgStream = new BufferedInputStream(
		   this.getClass().getResourceAsStream(path));
		if (imgStream != null) {
			byte buf[] = new byte[MAX_IMAGE_SIZE];
			try {
				count = imgStream.read(buf);
				imgStream.close();
			} catch (java.io.IOException ioe) {
				System.err.println("Couldn't read stream from file: " + path);
				return null;
			}
			if (count <= 0) {
				System.err.println("Empty file: " + path);
				return null;
			}
			return new ImageIcon(Toolkit.getDefaultToolkit().createImage(buf));
		} else {
			System.err.println("Couldn't find file: " + path);
			return null;
		}
	}



	@Override
	public void stop()
	{
		super.stop();
		if (cc!=null)
			cc.close();
	}



	public class RBListener implements ActionListener
	{
		String var;
		Object val;
		Date starttime;

		public RBListener(String _var, Object _val, Date _startTime)
		{
			var=_var;
			val=_val;
			starttime=_startTime;
		}

		@Override
		public void actionPerformed(ActionEvent e)
		{
			checkFulfilled();
			final Object[] o={var,val,new Long(new Date().getTime() - starttime.getTime())};
			cc.send(ServerCommand.SUBMIT_VALUE, o);	
		}

	}



	public class CBListener implements ActionListener
	{
		String var;
		JCheckBox val;
		Date starttime;

		public CBListener(String _var, JCheckBox _val, Date _startTime)
		{
			var=_var;
			val=_val;
			starttime=_startTime;
		}

		@Override
		public void actionPerformed(ActionEvent e)
		{
			checkFulfilled();
			final Object[] o={var,val.isSelected()?new Double(1):new Double(0),new Long(new Date().getTime() - starttime.getTime())};
			cc.send(ServerCommand.SUBMIT_VALUE, o);	
		}

	}



	public class ABListener implements ActionListener
	{
		String var;
		Object val;
		Date starttime;

		public ABListener(String _var, Date _starttime)
		{
			var=_var;
			val=new Double(1);
			starttime=_starttime;
		}

		@Override
		public void actionPerformed(ActionEvent e)
		{
			checkFulfilled();
			final Object[] o={var,val,new Long(new Date().getTime() - starttime.getTime())};

			cc.send(ServerCommand.SUBMIT_VALUE, o);
		}
	}
	
	public synchronized void setServerSideValid(ServerSideValidInfo ssvi) {
		serverSideValid=ssvi.ssvi;
		checkFulfilled();
	}

}
