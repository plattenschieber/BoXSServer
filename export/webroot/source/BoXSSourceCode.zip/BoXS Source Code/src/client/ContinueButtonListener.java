package client;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

import javax.swing.JButton;

public class ContinueButtonListener implements ActionListener
{
	JButton jb;
	ClientConnection cc;
	String name, pressedtext;
	Date starttime;
	ClientApplet ca;

	public ContinueButtonListener(ClientApplet _ca, JButton _jb, ClientConnection _cc, String _name, String _pressedtext, Date _startTime)
	{
		ca=_ca;
		jb=_jb;
		cc=_cc;
		name=_name;
		starttime=_startTime;
		pressedtext=_pressedtext;
	}

	@Override
	public void actionPerformed(ActionEvent arg0)
	{
		ca.waitButtonPressed=true;
		ca.checkFulfilled();
		final Object[] o={"_continue"+name,new Double(1),new Long(new Date().getTime() - starttime.getTime())};
		cc.send(ServerCommand.SUBMIT_VALUE, o);
		jb.setText(pressedtext);
		if (jb.getWidth() < jb.getPreferredSize().width)
			jb.setSize(jb.getPreferredSize());
//		jb.setEnabled(false);
	}

}
