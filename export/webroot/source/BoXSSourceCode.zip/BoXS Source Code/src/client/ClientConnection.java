package client;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class ClientConnection extends ConnChannel {

	ClientApplet ca;
	
	ClientConnection(ObjectOutputStream _out, ObjectInputStream _in, ClientApplet _ca, BufferedOutputStream _bos, OutputStream _os) throws IOException
	{
		super(_out, _in, _bos, _os);
		ca=_ca;
	}



	public void loginToServer(final String username, final String realm, final String password) throws Exception
	{
		String[] s=new String[3];
		s[0]=username;
		s[1]=realm;
		s[2]=password;
		send(ServerCommand.LOGIN,s);
	}

	public void send(final ServerCommand dt, final Object content)
	{
		Object[] temp=new Object[2];
		temp[0]=dt; temp[1]=content;
		send(temp);
	}
	
	boolean updatingstuff=false;

	@Override
	public void receive(final Object o) 
	{
		if (ca.experimenter)
		{
			if (o instanceof ErrorMessage)
			{
				((ErrorMessage)o).add();
				ErrorMessage.show();
			}
			else
			{
				if (!updatingstuff)
				{
					updatingstuff=true;
					SwingUtilities.invokeLater(new Runnable() {
					
					@Override
					public void run() {
							((ExperimenterPanel)ca.mainPanel).updateData(o);
							updatingstuff=false;
						}
					});
				}
				else
					System.out.println("Discarding data package");
			}
		}
		else
		{

			if (o instanceof String)
			{
				ca.executeSubjectUpdate((String)o);
			}
			else if (o instanceof ServerSideValidInfo)
				ca.setServerSideValid(((ServerSideValidInfo)o));

		}
	}

	static boolean disconnectmessageshown=false;
	public void close()
	{
		super.close();
		if (!disconnectmessageshown)
		{ 
			disconnectmessageshown=true;
			JOptionPane.showMessageDialog(null, "Client has been disconnected!");
		}
		if (!ca.experimenter)
			ca.executeSubjectUpdate("-1@display(\"<br>Client disconnected.\")");


	}


}
