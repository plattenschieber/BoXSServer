package client;

import java.io.Serializable;

public class ServerSideValidInfo implements Serializable{
public ServerSideValidInfo(boolean _ssvi) {
		ssvi=_ssvi;
		//System.out.println(ssvi);
		}
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
boolean ssvi;
}
