package server;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

public class Server {
	final static HashMap<Integer, Object[]> waitlist=new  HashMap<Integer, Object[]>();
	static int count=0; 
	
	static final int BUFFER_UPSTREAM=4000000;
	static final int BUFFER_DOWNSTREAM=1000000;
	

	private static String getInfoString() {
		return new Date().toString()
				+"  Port:"+_port
				+"  Mem:"+Runtime.getRuntime().freeMemory()
				+"  SubP:"+ServerClientThread.subjectPool.size()
				+"  ExpP:"+ServerClientThread.experimenterPool.size()
				+"  SusP:"+ServerClientThread.suspendedPool.size()
				+"  Autorun:"+ServerClientThread.autorunPrograms.size()
				+"  ConnC:"+ServerClientThread.globalcount;
	}

	static int _port=58000;
	
	public static void main(String[] args)
	{

		new Timer().scheduleAtFixedRate(new TimerTask() {
			
			@Override
			public void run() {
				Runtime.getRuntime().gc();
				System.out.println(getInfoString());
			}

		}, 0, 1000*60*2);
		
		if (args.length>=1)
		{
			System.out.println(args[0]);
			if (args[0].indexOf("enableMail")!=-1)
			{
				SmtpSend.active=true;
				System.out.println("Mail account active");
			}
			
			if (args.length>=2)
			{
				final 	String keepaliveaddress=args[1];
				System.out.println(keepaliveaddress);
				
				Runtime.getRuntime().addShutdownHook(new Thread()
				{
					@Override
					public void run() {
						super.run();
						SmtpSend.sendMail(keepaliveaddress,"I am dead :( :( :(!","... not alive, not alive...\n"+getInfoString(), null);
						
					}
				});
				
				new Timer().scheduleAtFixedRate(new TimerTask()
				{
					@Override
					public void run() {
						SmtpSend.sendMail(keepaliveaddress,"I am alive! Connections: "+ServerClientThread.globalcount,"... still alive, still alive...\n"+getInfoString(), null);
						
					}
				}, 1000, 1000*60*60*24);
			}

			if (args.length>=3)
			{
				_port=Integer.parseInt(args[2]);
			}

			if (args.length>=4)
			{
				ServerClientThread.DEFAULT_MINIMUM_UPDATEDELAY=Integer.parseInt(args[3]);
			}

		}
		final int port=_port;
		
		System.out.println("port="+port);
		
		new Thread()
		{
			@Override
			public void run() {
				try{
					ServerSocket ss=new ServerSocket(port);
					System.out.println("Port A open...");

					while (true)
					{
						try
						{
							final Socket skt=ss.accept();
							new Thread()
							{
								public void run() {
									int mynum=count++;
									System.out.println(new java.util.Date()+"Connection A accepted from "+skt.getRemoteSocketAddress()+" = "+count);
									try
									{
										Object[] temp=new Object[3];
										BufferedOutputStream bos=new BufferedOutputStream(skt.getOutputStream(),BUFFER_UPSTREAM);
										//ObjectOutputStream oos=new ObjectOutputStream(bos);
										//BufferedOutputStream bos=new BufferedOutputStream(oos,BUFFER_UPSTREAM);
										ObjectOutputStream oos=new ObjectOutputStream(bos);
										temp[0]=oos;
										temp[1]=bos;
										temp[2]=skt.getOutputStream();
					//					ObjectOutputStream oos=new ObjectOutputStream(skt.getOutputStream());
										waitlist.put(mynum,temp);

//										ObjectOutputStream
										oos.writeObject(new Integer(mynum));
										//skt.getOutputStream().write(count);
										//skt.getOutputStream().flush();
										oos.flush();
									}
									catch (Exception e)
									{
										e.printStackTrace();
									}
								};
							}.start();
						}
						catch (Exception e)
						{
							e.printStackTrace();
						}
					}
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		}.start();

		
		
		new Thread()
		{
			@Override
			public void run() {
				try{
					ServerSocket ss=new ServerSocket(port+1);
					System.out.println("Port B open...");

					while (true)
					{
						try
						{
							final Socket skt=ss.accept();
							new Thread()
							{
								public void run() {
									System.out.println(new java.util.Date()+"Connection B accepted from "+skt.getRemoteSocketAddress());
									
									new Timer().schedule(new TimerTask()
									{ @Override
									public void run() {
										try
										{

//											System.out.println("num = "+num);
											ObjectInputStream ois=new ObjectInputStream(new BufferedInputStream(skt.getInputStream(),BUFFER_DOWNSTREAM));
											//		ObjectInputStream ois=new ObjectInputStream(new BufferedInputStream(skt.getInputStream()));
//											ObjectInputStream ois=new ObjectInputStream(skt.getInputStream());
											int num=((Integer)ois.readObject()).intValue();

										
											new ServerClientThread((ObjectOutputStream)waitlist.get(num)[0],ois, skt.getRemoteSocketAddress(),
													(BufferedOutputStream)waitlist.get(num)[1], (OutputStream)waitlist.get(num)[2]).start();
											waitlist.remove(num);
										}
										catch (Exception e)
										{
											e.printStackTrace();
										}
									}
									},500);
									
									
								};
							}.start();
						}
						catch (Exception e)
						{
							e.printStackTrace();
						}
					}
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		}.start();

		
		
		
		
		
	}

}
