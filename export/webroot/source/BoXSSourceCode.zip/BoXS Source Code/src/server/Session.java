package server;

import interpreter.ExecutionEnvironment;
import interpreter.Function;
import interpreter.LexerParser;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedList;
import java.util.Map;
import java.util.Random;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

import client.ErrorMessage;
import client.FileExporter;



public class Session extends Thread
{
	static int count=0;
	public int num;
	//public Vector<ServerClientThread> subjects=new Vector<ServerClientThread>();
	public ServerClientThread experimenter;
	public String program;

	public ConcurrentHashMap<String, Object> varspace;
	public Date startTime;
	public Map<String, Group> groups=new ConcurrentHashMap<String, Group>();

	public boolean running=true;
	int matchingoffset=1;

	public Session(ServerClientThread _experimenter, String _program)
	{
		num=count++;
		startTime=new Date();
		program=_program;
		varspace=new ConcurrentHashMap<String, Object>();
		experimenter=_experimenter;
		experimenter.experiment=this;
	}

	public Session(ServerClientThread _experimenter, String _program, ConcurrentHashMap<String, Object> _varspace)
	{
		num=count++;
		startTime=new Date();
		varspace=_varspace;
		program=_program;
		experimenter=_experimenter;
		experimenter.experiment=this;
	}



	Vector<ServerClientThread> getAvailableSubjects()
	{
		Vector<ServerClientThread> temp=new Vector<ServerClientThread>();

		synchronized(ServerClientThread.subjectPool)
		{
			for (ServerClientThread sct:ServerClientThread.subjectPool)
				if (sct.experiment==null && sct.subinfo.realm.equals(experimenter.subinfo.realm))
					temp.add(sct);
		}
		return temp;
	}




	int matchingNum=0;

	@Override
	public void run() {
		super.run();

		System.out.println("Session started");
		
		new Thread()
		{
			public void run() {
				while(running)
				{
					try {
						synchronized(this)
						{
							sleep(1000*60*5);
						}
						if (autosend)
							sendSessionDataByMail("session running");
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}				
			};
			
		}.start();


		String[] lines=program.split("\n");

		boolean matchinginfo=false;
		// Check if matching info existent
    	for (int i=0; i<lines.length; i++)
    	{
    		String line=lines[i].trim();

    		if (line.startsWith("matchManual") || line.startsWith("matchAll")
    				|| line.startsWith("matchPerfectStranger") 
    				|| line.startsWith("matchStranger") || line.startsWith("matchDone")
    				|| line.startsWith("matchHistoryClear"))
    		{
    			matchinginfo=true;
    		}
    	}



    	if (matchinginfo)
    	{
	    	for (int i=0; i<lines.length && !cancel; i++)
	    	{
	    		String line=lines[i].trim();

	        	try
	        	{
		    		if (line.startsWith("matchManual"))
		    		{   			
		    			try
		    			{
		    				
			    			Vector<String> params=client.Utils.splitByComma(line.substring(line.indexOf('(')+1, line.indexOf(')')));
			    			ExecutionEnvironment ee=new ExecutionEnvironment(null,0,null,"",varspace,null);
			    			
			    			String username=LexerParser.evaluateExpression(params.get(0)).executeToString(ee);
			    			String group=LexerParser.evaluateExpression(params.get(1)).executeToString(ee);
			    			String role=LexerParser.evaluateExpression(params.get(2)).executeToString(ee);
			   				matchManual(lines, i+1, username,group,role,i);
		    			}
		    			catch(ErrorMessage pe)
		    			{
			        		experimenter.send(pe);
			        		pe.printStackTrace();
		    				
		    			}
		    			catch(Exception pe)
		    			{
			        		experimenter.send(new ErrorMessage(i, line, pe.getMessage(), new Date()));
			        		pe.printStackTrace();
		    				
		    			}
			        }
		    		else if (line.startsWith("matchAll"))
		    		{
		    			matchAll(lines, i+1, line.substring(line.indexOf('(')+1, line.indexOf(')')).split(","),i);
		   		    }
		    		else if (line.startsWith("matchPerfectStranger"))
		    		{
		   				matchPerfectStranger(lines, i+1, line.substring(line.indexOf('(')+1, line.indexOf(')')).split(","),i);
		   		   }
		     		else if (line.startsWith("matchStranger"))
		    		{
		   				matchStranger(lines, i+1, line.substring(line.indexOf('(')+1, line.indexOf(')')).split(","),i);
		   		   }
		    		else if (line.startsWith("matchDone"))
		    		{
		    			executeMatch();
		    		}
		    		else if (line.startsWith("matchHistoryClear"))
		    		{
		    			matchingNum=0;
		    		}
	        	}
	        	catch(ErrorMessage pe)
	        	{
	        		experimenter.send(pe);
	        		pe.printStackTrace();
	        	}

	    	}
    	}
    	else
    	{	// no matching info
    		String[] roles={"A"};
    		try
    		{
    			matchAll(lines, 0, roles,0);
        	}
        	catch(ErrorMessage em)
        	{
        		experimenter.send(em);
        		em.printStackTrace();
        	}
    	}

    	if (!groups.isEmpty())
    		executeMatch();

		System.out.println("Session finished");
		running=false;

		for (ServerClientThread sub:getAvailableSubjects())
		{
			//System.out.println("EX FINISH");
			sub.updates.clear();
			sub.updates.add("finish");
			sub.executeUpdate();
		}
		
		sendSessionDataByMail("session complete");
	}

	
	public void sendSessionDataByMail(String title)
	{
		
		
		if (experimenter.subinfo.username.length()>4)
		{
			// Export stuff and send it by mail
			String filename="export/"+experimenter.subinfo.realm+"-"+new Date().getTime()+".csv";

			try
			{

				
				// send file by mail
				String usermailaddr=experimenter.subinfo.username.substring(4).replaceAll("%40", "@");
				;
				if (usermailaddr.indexOf("@")==-1 || usermailaddr.indexOf(".")==-1)
				{
					System.out.println("invalid mail address: "+usermailaddr);
				}
				else if (SmtpSend.active)
				{
					// write varspace to file
					BufferedWriter bw=new BufferedWriter(new FileWriter(filename));
					String data=FileExporter.getExportString(varspace);
					bw.write(data);
					bw.close();
					
					final String message="Hello!\n\nthank you for using the Bonn Experiment System. Here is your data!\nPlease remember that you *must* cite the BoXS in your publication as \"Mirko Seithe (2010): Introducing the Bonn Experiment System (Discussion Paper)\".  \n\nPlease do not answer to this mail. If you have questions please visit boxs.uni-bonn.de";
					final String subject="Your experiment using the Bonn Experiment System: "+title;
					
					SmtpSend.sendMail(usermailaddr, subject, message, filename);
					System.out.println("Mail sent successfully to "+usermailaddr);
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
	}

	@SuppressWarnings("unchecked")
	private void matchPerfectStranger(String[] lines, int i, String[] roles, int linenum) throws ErrorMessage {
		int rolecount=roles.length;
		Vector<ServerClientThread> availableSubjects = getAvailableSubjects();
		int subjectcount=availableSubjects.size();
		int groupcount=(int)(subjectcount/rolecount);

		Vector<Function> parseProgram = LexerParser.parseProgram(findRemProg(lines, i), linenum+1);

		try
		{
			int redsubjectcount=subjectcount-subjectcount%rolecount;
			ObjectInputStream ois=new ObjectInputStream(new FileInputStream("pstables/"+redsubjectcount+"_"+rolecount+".dat"));
			Vector<int[]> assignments=(Vector<int[]>)ois.readObject();

			for (int j=0; j<groupcount; j++)
			{
				String groupname=""+(j+1);
				groups.put(groupname,new Group(this,groupname,linenum));
			}


			for (int j=0; j<redsubjectcount; j++)
			{
				int num=assignments.get(matchingNum)[j];
				String groupname=""+(num+1);
				Group g=groups.get(groupname);
				ServerClientThread subject = availableSubjects.get(j);
				toStart.add(g.assignSubjectToExperiment(this,subject,
						roles[g.subjects.size()], parseProgram,i+1,varspace));

			}
			matchingNum++;
			startMatchedPlayers();

		}
		catch(Exception e)
		{
			System.err.println("Error reading matching information.");
			e.printStackTrace();
		}
	}
	
	
	
	

	private void matchStranger(String[] lines, int i, String[] roles, int linenum) throws ErrorMessage {
		int groupcount=(int)(getAvailableSubjects().size()/roles.length);

		Vector<Function> parseProgram = LexerParser.parseProgram(findRemProg(lines, i), linenum+1);

		for (int g=1; g<=groupcount; g++)
		{
			String groupname=""+g;
			Group group=new Group(this,groupname, linenum);
			groups.put(groupname,group);

			for (String role:roles)
			{
				ServerClientThread element = getAvailableSubjects().get(new Random().nextInt(getAvailableSubjects().size()));
				toStart.add(group.assignSubjectToExperiment(this,element,
					role,  parseProgram,i+1,varspace));
			}
		}
		startMatchedPlayers();
	}
	
	
	
	


	private void matchManual(String[] lines, int i, String _subject,
			String _group, String role, int linenum) throws ErrorMessage {
		Group group=groups.get(_group);
		if (group==null)
		{
			group=new Group(this,_group, linenum);
			groups.put(_group,group);
		}

		ServerClientThread subject=null;
		for (ServerClientThread sct:getAvailableSubjects())
			if(sct.subinfo.username.equalsIgnoreCase(_subject))
				subject=sct;

		if (subject==null)System.out.println("subject not found: "+_subject);

		toStart.add(group.assignSubjectToExperiment(this,subject, role,  LexerParser.parseProgram(findRemProg(lines, i),linenum+1),i+1,varspace));
	}

	LinkedList<ExecutionEnvironment> toStart=new LinkedList<ExecutionEnvironment>();



	private void matchAll(String[] lines, int i, String[] roles, int linenum) throws ErrorMessage {
		int groupcount=(int)(getAvailableSubjects().size()/roles.length);

		Vector<Function> parseProgram = LexerParser.parseProgram(findRemProg(lines, i), linenum+1);
		for (int g=1; g<=groupcount; g++)
		{
			String groupname=""+g;
			Group group=new Group(this,groupname, linenum);
			groups.put(groupname,group);

			for (String role:roles) {
				toStart.add(group.assignSubjectToExperiment(this,getAvailableSubjects().firstElement(),
					role,  parseProgram,i+1,varspace));
			}
		}
		startMatchedPlayers();
	}


	private void startMatchedPlayers() {
		for (ExecutionEnvironment p:toStart)
			p.start();
		toStart.clear();
	}


	private String findRemProg(String[] lines, int i) {
		String remprg="";
		find_remprg: for (int j=i; j<lines.length; j++)
		{
			if (lines[j].trim().startsWith("matchDone"))
				break find_remprg;
			if (lines[j].trim().startsWith("matchManual") || lines[j].trim().startsWith("matchAll")
					|| lines[j].trim().startsWith("matchPerfectStranger")
					|| lines[j].trim().startsWith("matchHistoryClear"))
				remprg+="\n\n";
			else
				remprg+=lines[j]+"\n";

		}
		return remprg;
	}


	private void executeMatch() {
		startMatchedPlayers();

		for (Group g:groups.values())
			g.writeMatchingHistory();
		
	//	System.out.println("groups:");
		//for (Group g:groups.values())
			//System.out.println(g+" - "+g.subjects.size());

		System.out.println("MatchDone! Num="+groups.values().size());
		Collection<Group> values = new LinkedList<Group>(groups.values());
		for (Group g:values)
		{
			System.out.println("Waiting for group "+g.name+" to finish");
			{
				// Wiederholen falls sich scts ge�ndert haben
				for (int i=0; i<10; i++)
				for (ServerClientThread sct:g.subjects.values())
				{
					try
					{
				//		System.out.println("waiting for:"+sct.subinfo.username);
						if (sct.experimentParser!=null)
						sct.experimentParser.join();
					//	System.out.println("joined:"+sct.subinfo.username);
					}
					catch (InterruptedException e)
					{
						e.printStackTrace();
					}
					finally
					{
						sct.experiment=null;
					}
				}
			}
			System.out.println("group "+g.name+" finished");
		}

		groups.clear();
	}




	boolean cancel=false;
	public boolean autosend=false;

	public void cancelExperiment() {
		cancel=true;
		running=false;
		System.out.println("Cancel Experiment");
		for (Group g:groups.values())
			for (ServerClientThread s:g.subjects.values())
			{
				if (s.experimentParser!=null)
					s.experimentParser.cancel();
				if (ServerClientThread.suspendedPool.contains(s))
					ServerClientThread.suspendedPool.remove(s);
			}
	}

/*
	public void populate(int linenum)
	{
		if (!getAvailableSubjects().isEmpty())
		{
			System.out.println("Populating experiment");
			int maxnum=0;
			for (Group g:groups.values())
			{
				if (Integer.parseInt(g.name)>maxnum) maxnum=Integer.parseInt(g.name);
			}


			String groupname=""+(maxnum+1);
			Group group=new Group(this,groupname, linenum);
			groups.put(groupname,group);
			group.assignSubjectToExperiment(this,getAvailableSubjects().firstElement(),
					"a", program,0,varspace);
		}
	}
*/
	
/*
	private void saveData() {
		try
		{
			String filename="log//data-"+num+"-"+(startTime.getTime())+".csv";

			FileWriter fw=new FileWriter(filename);
			Vector<String> keyset=new Vector<String>(varspace.keySet());
			Collections.sort(keyset);

			for (String s:keyset)
				fw.write(s+";"+varspace.get(s)+"\n");
			fw.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	private void saveProgram() {
		try
		{
			String filename="log//prog-"+num+"-"+(startTime.getTime())+".csv";

			FileWriter fw=new FileWriter(filename);
			fw.write(program);
			fw.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}*/
}
