package server;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.SocketAddress;
import java.util.Collections;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

import client.ConnChannel;
import client.ExperimentSessionData;
import client.ServerCommand;
import client.SubjectInfo;

public class ServerClientThread extends ConnChannel implements Comparable<ServerClientThread>
{
	public LinkedList<String> lastUpdates=new LinkedList<String>();
	public LinkedList<String> updates=new LinkedList<String>();
	public int MINIMUM_UPDATEDELAY=200;

	public boolean experimenter=false;
	static int globalcount=0;

	public static Vector<ServerClientThread> subjectPool=new Vector<ServerClientThread>();
	public static Vector<ServerClientThread> experimenterPool=new Vector<ServerClientThread>();

	public static Vector<ServerClientThread> suspendedPool=new Vector<ServerClientThread>();
	public static int DEFAULT_MINIMUM_UPDATEDELAY;
	public static final Map<String, String> autorunPrograms=new ConcurrentHashMap<String, String>();
	public static final Map<String, Integer> autorunProgramsCounter=new ConcurrentHashMap<String, Integer>();
	public static final Map<String, ConcurrentHashMap<String, Object>> autorunProgramsVarspace=new ConcurrentHashMap<String, ConcurrentHashMap<String, Object>>();
	public static final Map<String, ServerClientThread> autorunProgramsExperimenter=new ConcurrentHashMap<String, ServerClientThread>();


	public final SubjectInfo subinfo=new SubjectInfo();
	public Session experiment;
	public interpreter.ExecutionEnvironment experimentParser;

	public boolean ready=false;

	Timer timeouttimer;
	
	public ServerClientThread(ObjectOutputStream out, ObjectInputStream in, SocketAddress adr, BufferedOutputStream _bos, OutputStream _os) throws IOException
	{
		super(out, in, _bos, _os);
		MINIMUM_UPDATEDELAY=DEFAULT_MINIMUM_UPDATEDELAY;
		subinfo.num=globalcount++;
		subinfo.socket=adr;
		timeouttimer=new Timer();
		timeouttimer.schedule(new TimerTask() {
			
			@Override
			public void run() {
				System.out.println("Closing due to timeout");
				close();
			}
		}, 1000*60*60*12);
	}

	
	public void receive(Object o)
	{
		Object[] temp=(Object[])o;
		((ServerCommand)temp[0]).execute(this, temp[1]);
	}

	
	public static boolean existsBySubjectname(String realmName, String subjectName)
	{
		synchronized(subjectPool)
		{
			for (ServerClientThread sct:subjectPool)
			{
				if (sct.subinfo.realm.equals(realmName) && sct.subinfo.username.equals(subjectName))
					return true;
			}
		}
		return false;
	}
	
	
	static final Hashtable<String, String> realmpasswords=new Hashtable<String, String>();
	
	public void login(String password)
	{
		// make sure username unique
		if (!experimenter && existsBySubjectname(subinfo.realm, subinfo.username))
		{
			for (int num=2; num<10000; num++)
			{
				if (!existsBySubjectname(subinfo.realm, subinfo.username+"_"+num))
				{
					subinfo.username=subinfo.username+"_"+num;
					break;
				}
			}
			
		}
		
		if (experimenter)
		{
			MINIMUM_UPDATEDELAY=1000;
			if (realmpasswords.containsKey(subinfo.realm))
			{
				if (!realmpasswords.get(subinfo.realm).equals(password))
				{
					System.out.println("Password for realm incorrect. Disconnecting");
					close();
					return;
				}
			} 
			else
			{
				realmpasswords.put(subinfo.realm, password);
			}
			
			ServerClientThread killoldexperimenter=null;
			for (ServerClientThread sct:experimenterPool)
			{
				if (sct.subinfo.realm.equals(subinfo.realm))
					killoldexperimenter=sct;
			}
			if  (killoldexperimenter!=null)
			{
				System.out.println("Killing old experimenter");
				killoldexperimenter.close();
			}
		}
		
		
		System.out.println(new java.util.Date()+"#"+subinfo.num+" Login: "+ subinfo.username + ":" + subinfo.realm+"@"+subinfo.socket);

		ServerClientThread matchingSuspendedThread=null;
		for (ServerClientThread sct:suspendedPool)
		{
			if (sct.subinfo.username.equals(subinfo.username) && sct.subinfo.realm.equals(subinfo.realm))
			{
				// Merge with suspended Thread
				matchingSuspendedThread=sct;
			}
		}
		
		
		
		if (matchingSuspendedThread!=null && !subinfo.username.toLowerCase().equals("new"))
		{
			System.out.println(new java.util.Date()+"#"+subinfo.num+" Reconnecting to experiment");
			suspendedPool.remove(matchingSuspendedThread);
			experiment=matchingSuspendedThread.experiment;
			experimentParser=matchingSuspendedThread.experimentParser;
			experimentParser.sct=this;
		
			if (!experimenter)
			{
				for (Group g:experiment.groups.values())
				{
					for (String r:g.subjects.keySet())
					{
						if (g.subjects.get(r) == matchingSuspendedThread)
						{
							subinfo.experimentGroup=g.name;
							subinfo.experimentRole=r;
							subinfo.inExperiment=true;
							g.subjects.put(r, this);
						}
					}
				}
				updates.addAll(matchingSuspendedThread.lastUpdates);
				experiment.varspace.put(subinfo.username+"._suspended", new Double(0));
			}

		}


		synchronized (subjectPool) {
			if (experimenter)
				experimenterPool.add(this);
			else
			{
				subjectPool.add(this);
				Collections.sort(subjectPool);
				notifyExperimenter();
			}
		}

		// Autorun??
		if (matchingSuspendedThread==null)
		{
			if (autorunPrograms.containsKey(subinfo.realm))
			{
				if (!autorunProgramsVarspace.containsKey(subinfo.realm))
					autorunProgramsVarspace.put(subinfo.realm, new ConcurrentHashMap<String, Object>());
				if (!autorunProgramsCounter.containsKey(subinfo.realm))
					autorunProgramsCounter.put(subinfo.realm, new Integer(0));
				autorunProgramsCounter.put(subinfo.realm, 
						autorunProgramsCounter.get(subinfo.realm)+1);

				if (subinfo.username.toLowerCase().equals("new"))
					subinfo.username="auto"+autorunProgramsCounter.get(subinfo.realm);

				Session es=new Session(autorunProgramsExperimenter.get(subinfo.realm),
								autorunPrograms.get(subinfo.realm),
								autorunProgramsVarspace.get(subinfo.realm));
				es.start();
			}
		}
		
		update();
	}


	public void notifyExperimenter() {
		for (ServerClientThread sct:experimenterPool)
		{
			if (sct.subinfo.realm.equals(subinfo.realm))
				sct.update();
		}
	}

	
	long lastupdate=0;
	boolean updatethreadRunning=false;
	public boolean details=false;
	
	
	public void update()
	{
	//	System.out.println("update");
		long time=new java.util.Date().getTime();
		if (time>lastupdate+MINIMUM_UPDATEDELAY)
		{
			lastupdate=time;
			executeUpdate();
		}
		else
		{
			if (!updatethreadRunning)
			{
				updatethreadRunning=true;
				new Timer().schedule(
						new TimerTask() {
					
							@Override
							public void run() {
								updatethreadRunning=false;
								update();
							}
						},MINIMUM_UPDATEDELAY);
			}
		}
	}
	
	String lastUpdate="";
	
	public void executeUpdate()
	{
		//System.out.println("exupdate");
//		System.out.println("update "+subinfo.username);
		if (experimenter)
		{	
			Object ret=new Object[3];
			// Experimentdaten
			if (experiment!=null)
			{
				((Object[])ret)[0]=new ExperimentSessionData(experiment,details);
			//	if (!experiment.running)
				//	experiment=null;

			}

			// Subjektdaten
			Vector<SubjectInfo> subinfos=new Vector<SubjectInfo>();

			synchronized(subjectPool)
			{
			for (ServerClientThread subject:ServerClientThread.subjectPool)
			{
				if (!subject.subinfo.realm.equals(subinfo.realm)) continue;
				SubjectInfo si=subject.subinfo.clone();
				si.inExperiment=subject.experiment!=null;
				si.isSuspended=false;
				subinfos.add(si);
			}
			}

			for (ServerClientThread subject:ServerClientThread.suspendedPool)
			{
				if (!subject.subinfo.realm.equals(subinfo.realm)) continue;
				SubjectInfo si=subject.subinfo.clone();
				si.inExperiment=subject.experiment!=null;
				si.isSuspended=true;
				subinfos.add(si);
			}

			((Object[])ret)[1]=subinfos;

			// Autorun-Experiment?
			((Object[])ret)[2]=new Boolean(autorunPrograms.containsKey(subinfo.realm));

			send(ret);
		}
		else
		{
			if (!updates.isEmpty())
			{
				String ret="";
				lastUpdates.clear();
				lastUpdates.addAll(updates);

				for (String s:updates)
					ret=ret+s+"\n";
				updates.clear();
				
				// if (!ret.equals(lastUpdate))
				{
					lastUpdate=ret;
					send(ret);
					notifyExperimenter();
				}
			}
		}
	}
	
	
	
	
	boolean wasclosed=false;
	
	public synchronized void close()
	{	
		if (!wasclosed)
		{
			wasclosed=true;
			System.out.println(new java.util.Date()+"#"+subinfo.num+" Disconnect: "+ subinfo.username + ":" + subinfo.realm+"@"+subinfo.socket);
			synchronized(subjectPool) 
			{
				if (experiment==null)
				{
					System.out.println(new java.util.Date()+"#"+subinfo.num+" Closing connection");
					subjectPool.remove(this);
					experimenterPool.remove(this);
				}
				else if (experimenter || (experimentParser!=null && !experimentParser.finished))
				{
					System.out.println(new java.util.Date()+"#"+subinfo.num+" Disconnected during experiment!");
					if (!experimenter)
						experiment.varspace.put(subinfo.username+"._suspended", new Double(1));
					subjectPool.remove(this);
					experimenterPool.remove(this);
					suspendedPool.add(this);
					new Timer().schedule(new RemoveSuspendedTT(this), 1000*60*60);
				}
			}
			
			notifyExperimenter();
			
			try
			{
				timeouttimer.cancel();
			}
			catch(Exception e)
			{
				;
			}
		}
		super.close();
	}

	class RemoveSuspendedTT extends TimerTask
	{
		ServerClientThread sct;
		RemoveSuspendedTT(ServerClientThread _sct)
		{
			sct=_sct;
		}
		
		@Override
		public void run() {
			if (suspendedPool.contains(sct))
			{
				System.out.println(new java.util.Date()+"Removing suspended sct from list");
				suspendedPool.remove(sct);
			}

		}
	}


	@Override
	public int compareTo(ServerClientThread o)
	{
		return subinfo.username.compareTo(o.subinfo.username);
	}

}
