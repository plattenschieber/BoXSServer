package server;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;

public class PerfectStrangerMatcher {


	private static Vector<int[]> getPermutations(int subjectcount, int rolecount)
	{
		if (subjectcount%rolecount!=0) throw new IllegalArgumentException("illegal subject/role ratio");
		Vector<int[]> ret=new Vector<int[]>();
		int[] temp=new int[subjectcount];
		for (int i=0; i<subjectcount; i++)
			temp[i]=i/rolecount;
		ret.add(temp);
		getPermutations(ret,subjectcount,subjectcount/rolecount,rolecount,new int[0],subjectcount);
		return ret;
	}

	private static void getPermutations(final Vector<int[]> ret, final int subjectcount,
			final int teamcount, final int rolecount, final int[] history, final int left)
	{
		if (left==0)
		{
		/*	// f�r jedes Subject...
			for (int i=0; i<subjectcount; i++)
			{
				// und jedes andere Subject...
				for (int j=0; j<i; j++)
				{
					// pr�fe ob sie sich gesehen haben...
					for (final int[] h:ret)
					{
						if (h[i]==h[j] && history[i]==history[j])
						{
							return;
						}
					}
				}
			}
*/
			ret.add(history);
			return;
		}


		x: for (int i=0; i<teamcount; i++)
		{
//			 if (cancel) break;
			int countedi=0;
			// test ob zu gro�e teams...
			for (int j=0; j<history.length; j++)
			{
				if (history[j]==i)
				{
					countedi++;
					if (countedi>=rolecount) continue x;
				}
			}



			// test ob �berschneidung
			int testpos=history.length;
			for (int k=0; k<testpos; k++)
			{
				for (final int[] otherMatch:ret)
				{
					if (otherMatch[k]==otherMatch[testpos] && history[k]==i)
					{
						continue x;
					}
				}
			}

			for (int k=0; k<testpos; k++)
			{
				// und jedes andere Subject...
				for (int j=0; j<k; j++)
				{
					// pr�fe ob sie sich gesehen haben...
					for (final int[] otherMatch:ret)
					{
						if (otherMatch[k]==otherMatch[j] && history[k]==history[j])
						{
							continue x;
						}
					}
				}
			}


			int[] h=new int[history.length+1];
			for (int j=0; j<history.length; j++)
				h[j]=history[j];

			h[h.length-1]=i;

			getPermutations(ret, subjectcount, teamcount,rolecount, h, left-1);
		}
	}




/*

	public static int[][] getAllAssignments(int subjectcount, int rolecount)
	{
		final Vector<int[]> permutations=getPermutations(subjectcount, rolecount);


		int[][] history = new int[1][subjectcount];
		history[0]=permutations.get(0);
		int[][] bestHistory=getNextAssignment(permutations, subjectcount, history);
		return bestHistory;
	}



	private static int[][] getNextAssignment(final Vector<int[]> permutations,
			final int subjectcount, final int[][] history)
	{
		int[][] bestHistory=null;
		final Vector<int[]> permutations2=new Vector<int[]>(permutations);
		final Vector<int[]> valid=new Vector<int[]>();

		loop_perm: for (final int[] perm:permutations)
		{
			if (cancel) break;
			// f�r jedes Subject...
			for (int i=0; i<subjectcount; i++)
			{
				// und jedes andere Subject...
				for (int j=0; j<subjectcount; j++)
				{
					if (i==j) continue;

					// pr�fe ob sie sich gesehen haben...

					for (final int[] h:history)
					{
						if (h[i]==h[j])
						{// haben sich gesehen!
							// und pr�fe ob sie sich wieder sehen
							if (perm[i]==perm[j])
							{
								permutations2.remove(perm);
								continue loop_perm;
							}
						}
					}
				}
			}
			valid.add(perm);
		}

		for (int[] perm:valid)
		{
			if (cancel) break;
			// G�ltig, neue Historie erstellen und rekursiv weiter
			final int[][] newHistory=new int[history.length+1][subjectcount];
			for (int k=0; k<history.length; k++)
				newHistory[k]=history[k];
			newHistory[history.length]=perm;

			int[][] resHist=getNextAssignment(permutations2, subjectcount, newHistory);
			if (bestHistory==null || resHist.length>bestHistory.length)
				bestHistory=resHist;
		}




		if (bestHistory==null) return history;
		else return bestHistory;

	}

*/
	static boolean cancel;



	public static void main(String[] args)
	{
//		int maxtime=Integer.parseInt(args[2]);

	//	Timer t=null;

		for (int sc=Integer.parseInt(args[0]); sc<=Integer.parseInt(args[1]); sc++)
		for (int rc=Integer.parseInt(args[2]); rc<sc; rc++)
		{
			if (sc%rc!=0) continue;

			//if (t!=null) t.cancel();
		//	t=new Timer();
			cancel=false;

		/*	TimerTask tt=new TimerTask()
			{
				 @Override
				public void run() {
					cancel=true;
				}
			};*/
		//	t.schedule(tt, maxtime);

			test(sc,rc);

		}


	}

	private static void test(int sc, int rc) {
		System.out.println("\ncalculating SC="+sc+"  RC="+rc);
		Vector<int[]> allAssignments = getPermutations(sc,rc);
//		int[][] allAssignments = getAllAssignments(sc,rc);
		System.out.println("SC="+sc+"  RC="+rc+"  #="+allAssignments.size());
	/*	for (int[] t:allAssignments)
		{
			for (int j:t)
			{
				System.out.print(" "+j);
			}
			System.out.println();
		}*/

		try
		{
			ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("pstables/"+sc+"_"+rc+".dat"));
			oos.writeObject(allAssignments);
			oos.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}


	}
}
