package server;

import interpreter.ExecutionEnvironment;
import interpreter.Function;

import java.util.Map;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

public class Group{
	public Session session;
	public String name;
	public Map<String, ServerClientThread> subjects=new ConcurrentHashMap<String, ServerClientThread>();
	int linenum;
	public Group(Session _session, String _name, int linenum)
	{
		session=_session;
		name=_name;
	}


	public ExecutionEnvironment assignSubjectToExperiment(
			Session session, ServerClientThread sct, String role, Vector<Function> subjectProgram, int startLineNum,
			Map<String, Object> varspace)
	{
		System.out.println("#"+sct.subinfo.num+" Subject "+sct.subinfo.username+" ->  Group "+name+" Role "+role);//+" Prog ["+subjectProgram+"]");
		subjects.put(role,sct);
		//session.add(this);
		sct.experiment=session;
		sct.experimentParser=new ExecutionEnvironment(subjectProgram,startLineNum,sct,
				role,
				varspace, this);
		return sct.experimentParser;
		//sct.experimentParser.start();
	}

	public void writeMatchingHistory()
	{
		for (ServerClientThread sct:subjects.values())
			sct.experimentParser.writeMatchingHistory(linenum);

	}

}
