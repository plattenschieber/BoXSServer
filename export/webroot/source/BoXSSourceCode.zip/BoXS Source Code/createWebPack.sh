mkdir offlineserver
mkdir offlineserver/server
mkdir offlineserver/server/export
mkdir offlineserver/client

jar -cf webroot/expsys/es.jar -C bin client
jarsigner -keystore keystore.jks webroot/expsys/es.jar mykey

jar -cf offlineserver/server/server.jar -C bin .
cp lib/mail.jar offlineserver/server/mail.jar
echo "java -xmx500m -xms500m -cp server.jar;mail.jar server.Server" > offlineserver/server/server.bat
echo "java -xmx500m -xms500m -cp server.jar:mail.jar server.Server" > offlineserver/server/server.sh

cp webroot/indexoffline.html offlineserver/client/index.html
cp -r webroot/expsys offlineserver/client/expsys

zip -r webroot/general/offlineserver.zip offlineserver
rm -r offlineserver

