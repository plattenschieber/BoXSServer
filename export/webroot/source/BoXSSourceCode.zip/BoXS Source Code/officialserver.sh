#!/bin/bash

java -server -Djava.library.path=lib -cp bin:lib/mail.jar server.Server enableMail mseithe@uni-bonn.de
pause
