keytool -genkey -alias mykey -keyalg RSA -keystore "keystore.jks"
keytool -selfcert -keystore "keystore.jks"
