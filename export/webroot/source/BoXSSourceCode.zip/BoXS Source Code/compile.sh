mkdir bin
javac -d bin -classpath lib/mail.jar:lib/jmf.jar -sourcepath src src/client/*.java src/interpreter/*.java src/server/*.java
